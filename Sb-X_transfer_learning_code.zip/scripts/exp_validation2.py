# -*- coding: utf-8 -*-
"""实验验证：完整模型预测 vs 实验形成焓"""
import os, json
import numpy as np
import pandas as pd
import importlib.util

_HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(_HERE, "..", "results")
OUT_DIR = OUT
DATA = os.path.join(_HERE, "..", "data")
os.makedirs(OUT, exist_ok=True)
_spec = importlib.util.spec_from_file_location("pipeline", os.path.join(OUT, "run_pipeline_dft.py"))
_pipe = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_pipe)
ELEMENT_PROPS = _pipe.ELEMENT_PROPS
compute_descriptors = _pipe.compute_descriptors_for_binary
train_xgb = _pipe.train_xgb

FEATURES = ["epsilon","dchi","dm","dTm","c","dI","dK","VEC",
            "epsilon2","dchi2","dm2","epsilon_c","dchi_c","dm_c",
            "dH_mix","dS_mix"]

df_pre = _pipe.build_pretrain_dataset(pd.read_csv(os.path.join(DATA, "mp_pretrain_binary.csv")))
df_sbx = _pipe.build_sbx_dataset(pd.read_csv(os.path.join(DATA, "mp_sbx_binary.csv")))

X_pre = df_pre[FEATURES].values
y_pre = df_pre["E_form"].values
X_sbx = df_sbx[FEATURES].values
y_sbx = df_sbx["E_sub"].values

pre_model = train_xgb(X_pre, y_pre, n_estimators=300, max_depth=6, lr=0.1, seed=42)
ft_model = train_xgb(X_sbx, y_sbx, n_estimators=200, max_depth=4, lr=0.1, xgb_init=pre_model, seed=42)

# 实验数据 (Chemical Reviews 2013, cr400050e)
# ΔH°298 in kJ/mol of formula unit → eV/atom (/2/96.485)
exp = {
    'Al': ('AlSb', -51.156),
    'Ga': ('GaSb', -41.587),
    'In': ('InSb', -30.400),
    'Cd': ('CdSb', -6.67),
    'Zn': ('ZnSb', -15.68),
}

print("化合物 | 实验ΔH(eV/atom) | DFT(eV/atom) | 模型预测(eV/atom) | DFT偏差 | 模型偏差")
print("-" * 85)
results = []
for elem, (formula, dH_kj) in exp.items():
    exp_ev = dH_kj / 2 / 96.485
    desc = compute_descriptors("Sb", elem, 0.5)
    x = np.array([[desc[f] for f in FEATURES]])
    pred = ft_model.predict(x)[0]
    
    # DFT值
    sub = df_sbx[(df_sbx['elem_b']==elem) & (np.isclose(df_sbx['c_b'], 0.5, atol=0.01))]
    dft = sub['E_sub'].values[0] if len(sub)>0 else np.nan
    
    dft_err = abs(dft - exp_ev) if not np.isnan(dft) else np.nan
    pred_err = abs(pred - exp_ev)
    print(f"{formula:6s} | {exp_ev:8.3f}      | {dft:8.3f}     | {pred:8.3f}        | {dft_err:.3f}   | {pred_err:.3f}")
    results.append({'formula': formula, 'elem': elem, 'exp': exp_ev, 'dft': dft, 'pred': pred})

# Si-Sb外推
desc_si = compute_descriptors("Sb", "Si", 0.0864)
x_si = np.array([[desc_si[f] for f in FEATURES]])
pred_si = ft_model.predict(x_si)[0]
print(f"\nSi-Sb (c=8.64%): 模型预测 = {pred_si:.3f} eV/atom (稳定)")
print(f"  实验文献[3]: Si掺杂Sb薄膜稳定, 10年保持152°C")

# 保存
import json
with open(os.path.join(OUT, "exp_validation_results.json"), "w") as f:
    json.dump({"compounds": results, "Si_Sb_8.64pct": float(pred_si)}, f, indent=2)
