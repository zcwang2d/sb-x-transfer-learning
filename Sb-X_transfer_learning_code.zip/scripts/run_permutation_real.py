# -*- coding: utf-8 -*-
"""
Real permutation test (200 runs, 5-fold CV) with true data,
then plot histogram with the actual 200 R2 values.
"""
import os, json, re
import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.model_selection import KFold
from sklearn.metrics import r2_score
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["mathtext.fontset"] = "stix"
plt.rcParams["font.size"] = 16

_HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(_HERE, "..", "results")
OUT_DIR = OUT
DATA = os.path.join(_HERE, "..", "data")
os.makedirs(OUT, exist_ok=True)
DPI = 1200
SEED = 42

ELEMENT_PROPS = {
    "H": (0.31, 2.20, 1.008, 14.01, 13.60, 0.0, 1),
    "Li": (1.28, 0.98, 6.941, 453.69, 5.39, 0.11, 1),
    "Be": (0.96, 1.57, 9.012, 1560, 9.32, 1.3, 2),
    "B": (0.84, 2.04, 10.81, 2349, 8.30, 3.2, 3),
    "C": (0.76, 2.55, 12.011, 3823, 11.26, 4.4, 4),
    "N": (0.71, 3.04, 14.007, 63.15, 14.53, 0.0, 5),
    "O": (0.66, 3.44, 15.999, 54.36, 13.62, 0.0, 6),
    "F": (0.57, 3.98, 18.998, 53.53, 17.42, 0.0, 7),
    "Na": (1.66, 0.93, 22.990, 370.87, 5.14, 0.068, 1),
    "Mg": (1.41, 1.31, 24.305, 923, 7.65, 0.45, 2),
    "Al": (1.21, 1.61, 26.982, 933.47, 5.99, 0.76, 3),
    "Si": (1.11, 1.90, 28.086, 1687, 8.15, 1.0, 4),
    "P": (1.07, 2.19, 30.974, 317.30, 10.49, 0.0, 5),
    "S": (1.05, 2.58, 32.065, 388.36, 10.36, 0.0, 6),
    "Cl": (1.02, 3.16, 35.453, 171.6, 12.97, 0.0, 7),
    "K": (2.03, 0.82, 39.098, 336.53, 4.34, 0.032, 1),
    "Ca": (1.76, 1.00, 40.078, 1115, 6.11, 0.17, 2),
    "Sc": (1.70, 1.36, 44.956, 1814, 6.56, 0.44, 3),
    "Ti": (1.60, 1.54, 47.867, 1941, 6.83, 1.1, 4),
    "V": (1.53, 1.63, 50.942, 2183, 6.75, 1.6, 5),
    "Cr": (1.39, 1.66, 51.996, 2180, 6.77, 1.9, 6),
    "Mn": (1.39, 1.55, 54.938, 1519, 7.43, 1.0, 7),
    "Fe": (1.32, 1.83, 55.845, 1811, 7.90, 1.7, 8),
    "Co": (1.26, 1.88, 58.933, 1768, 7.88, 2.0, 9),
    "Ni": (1.24, 1.91, 58.693, 1728, 7.64, 2.0, 10),
    "Cu": (1.32, 1.90, 63.546, 1357.77, 7.73, 1.4, 11),
    "Zn": (1.22, 1.65, 65.38, 692.68, 9.39, 0.7, 12),
    "Ga": (1.22, 1.81, 69.723, 302.91, 5.999, 0.68, 3),
    "Ge": (1.20, 2.01, 72.64, 1211.40, 7.90, 0.75, 4),
    "As": (1.19, 2.18, 74.922, 1090, 9.81, 0.0, 5),
    "Se": (1.20, 2.55, 78.96, 494, 9.75, 0.0, 6),
    "Br": (1.20, 2.96, 79.904, 265.8, 11.81, 0.0, 7),
    "Rb": (2.20, 0.82, 85.468, 312.46, 4.18, 0.024, 1),
    "Sr": (1.95, 0.95, 87.62, 1050, 5.69, 0.12, 2),
    "Y": (1.90, 1.22, 88.906, 1799, 6.22, 0.41, 3),
    "Zr": (1.75, 1.33, 91.224, 2128, 6.63, 0.95, 4),
    "Nb": (1.64, 1.6, 92.906, 2750, 6.76, 1.7, 5),
    "Mo": (1.54, 2.16, 95.96, 2896, 7.09, 2.3, 6),
    "Ru": (1.46, 2.2, 101.07, 2607, 7.36, 3.2, 8),
    "Rh": (1.42, 2.28, 102.906, 2237, 7.46, 3.0, 9),
    "Pd": (1.39, 2.20, 106.42, 1828.05, 8.34, 2.2, 10),
    "Ag": (1.45, 1.93, 107.868, 1234.93, 7.58, 1.0, 11),
    "Cd": (1.44, 1.69, 112.411, 594.22, 8.99, 0.5, 12),
    "In": (1.42, 1.78, 114.818, 429.75, 5.786, 0.41, 3),
    "Sn": (1.39, 1.96, 118.710, 505.08, 7.34, 0.58, 4),
    "Sb": (1.38, 2.05, 121.760, 903.78, 8.64, 0.0, 5),
    "Te": (1.38, 2.1, 127.60, 722.66, 9.01, 0.0, 6),
    "I": (1.39, 2.66, 126.904, 386.85, 10.45, 0.0, 7),
    "Cs": (2.44, 0.79, 132.905, 301.59, 3.89, 0.017, 1),
    "Ba": (2.15, 0.89, 137.327, 1000, 5.21, 0.10, 2),
    "La": (2.07, 1.10, 138.905, 1193, 5.58, 0.36, 3),
    "Ce": (2.04, 1.12, 140.116, 1068, 5.54, 0.34, 4),
    "Pr": (2.03, 1.13, 140.908, 1208, 5.47, 0.32, 5),
    "Nd": (2.01, 1.14, 144.242, 1297, 5.53, 0.31, 6),
    "Sm": (1.98, 1.17, 150.36, 1345, 5.64, 0.30, 8),
    "Eu": (1.98, 1.2, 151.964, 1099, 5.67, 0.18, 9),
    "Gd": (1.96, 1.20, 157.25, 1585, 6.15, 0.38, 10),
    "Tb": (1.94, 1.2, 158.925, 1629, 5.86, 0.39, 11),
    "Dy": (1.92, 1.22, 162.50, 1680, 5.94, 0.41, 12),
    "Ho": (1.92, 1.23, 164.930, 1734, 6.02, 0.40, 13),
    "Er": (1.89, 1.24, 167.259, 1802, 6.11, 0.42, 14),
    "Tm": (1.90, 1.25, 168.934, 1818, 6.18, 0.40, 15),
    "Yb": (1.94, 1.1, 173.054, 1097, 6.25, 0.25, 16),
    "Lu": (1.87, 1.27, 174.967, 1925, 5.43, 0.42, 17),
    "Hf": (1.75, 1.3, 178.49, 2506, 6.83, 1.5, 4),
    "Ta": (1.70, 1.5, 180.948, 3290, 7.55, 2.0, 5),
    "W": (1.62, 2.36, 183.84, 3695, 7.86, 3.1, 6),
    "Re": (1.51, 1.9, 186.207, 3459, 7.88, 3.7, 7),
    "Os": (1.44, 2.2, 190.23, 3306, 8.7, 4.0, 8),
    "Ir": (1.41, 2.20, 192.217, 2719, 8.97, 3.9, 9),
    "Pt": (1.36, 2.28, 195.084, 2041.4, 9.0, 2.8, 10),
    "Au": (1.36, 2.54, 196.967, 1337.33, 9.23, 2.2, 11),
    "Hg": (1.32, 2.00, 200.59, 234.32, 10.44, 1.4, 12),
    "Tl": (1.45, 1.62, 204.383, 577, 6.11, 0.43, 3),
    "Pb": (1.46, 1.87, 207.2, 600.61, 7.42, 0.56, 4),
    "Bi": (1.48, 2.02, 208.980, 544.7, 7.29, 0.32, 5),
    "Th": (2.06, 1.3, 232.038, 2115, 6.31, 0.31, 4),
    "Pa": (2.00, 1.5, 231.036, 1841, 5.89, 0.0, 5),
    "U": (1.96, 1.38, 238.029, 1405.3, 6.19, 0.0, 6),
    "Np": (1.90, 1.36, 237, 917, 6.27, 0.0, 7),
    "Pu": (1.87, 1.28, 244, 912.5, 6.06, 0.0, 8),
}

FEATURE_NAMES_16 = ["epsilon","dchi","dm","dTm","c","dI","dK","VEC",
                    "epsilon2","dchi2","dm2","epsilon_c","dchi_c","dm_c",
                    "dH_mix","dS_mix"]

def compute_descriptors(ea, eb, c_b):
    pa = ELEMENT_PROPS.get(ea)
    pb = ELEMENT_PROPS.get(eb)
    if pa is None or pb is None:
        return None
    ra, chia, ma, Tma, Ia, Ka, VECa = pa
    rb, chib, mb, Tmb, Ib, Kb, VECb = pb
    c_a = 1.0 - c_b
    epsilon = abs(rb - ra) / ra
    dchi = abs(chib - chia)
    dm = abs(mb - ma) / ma
    dTm = abs(Tmb - Tma) / Tma
    c = c_b
    dI = abs(Ib - Ia) / Ia
    dK = abs(Kb - Ka) / Ka if Ka > 0 else 0.0
    VEC = c_a * VECa + c_b * VECb
    epsilon2 = epsilon ** 2
    dchi2 = dchi ** 2
    dm2 = dm ** 2
    epsilon_c = epsilon * c_b
    dchi_c = dchi * c_b
    dm_c = dm * c_b
    Rconst = 8.314
    with np.errstate(divide="ignore", invalid="ignore"):
        dS_mix = -Rconst * (c_a * np.log(c_a + 1e-12) + c_b * np.log(c_b + 1e-12))
    P_miedema = 50.0
    Omega = -P_miedema * dchi ** 2
    dH_mix = 4.0 * c_a * c_b * Omega
    return {"epsilon": epsilon, "dchi": dchi, "dm": dm, "dTm": dTm,
            "c": c, "dI": dI, "dK": dK, "VEC": VEC,
            "epsilon2": epsilon2, "dchi2": dchi2, "dm2": dm2,
            "epsilon_c": epsilon_c, "dchi_c": dchi_c, "dm_c": dm_c,
            "dH_mix": dH_mix, "dS_mix": dS_mix}

def build_sbx_dataset(df_sbx):
    rows = []
    for _, row in df_sbx.iterrows():
        eb = str(row["other_element"]).strip()
        ea = "Sb"
        if eb not in ELEMENT_PROPS:
            continue
        c_b = float(row["dopant_fraction"])
        if np.isnan(c_b):
            continue
        desc = compute_descriptors(ea, eb, c_b)
        if desc is None:
            continue
        desc["material_id"] = row["material_id"]
        desc["formula"] = row["formula"]
        desc["E_form"] = float(row["formation_energy_per_atom"])
        desc["elem_b"] = eb
        desc["c_b"] = c_b
        rows.append(desc)
    return pd.DataFrame(rows)

def build_pretrain_dataset(df_pretrain):
    rows = []
    for _, row in df_pretrain.iterrows():
        elements = str(row["elements"]).split(",")
        if len(elements) != 2:
            continue
        ea, eb = elements[0].strip(), elements[1].strip()
        if ea not in ELEMENT_PROPS or eb not in ELEMENT_PROPS:
            continue
        # 源/目标严格隔离：剔除所有含 Sb 的记录（334 条 Sb-X 化合物只出现在微调集）
        if "Sb" in (ea, eb):
            continue
        formula = str(row["formula"])
        matches = re.findall(r"([A-Z][a-z]?)(\d*\.?\d*)", formula)
        if len(matches) != 2:
            continue
        (e1, n1), (e2, n2) = matches
        n1 = float(n1) if n1 else 1.0
        n2 = float(n2) if n2 else 1.0
        total = n1 + n2
        c1 = n1 / total
        c2 = n2 / total
        if e1 == ea:
            c_b = c2 if e2 == eb else c1
        else:
            c_b = c1 if e1 == eb else c2
            ea, eb = eb, ea
        desc = compute_descriptors(ea, eb, c_b)
        if desc is None:
            continue
        desc["material_id"] = row["material_id"]
        desc["formula"] = formula
        desc["E_form"] = float(row["formation_energy_per_atom"])
        rows.append(desc)
    return pd.DataFrame(rows)

def train_xgb(X_train, y_train, n_estimators=300, max_depth=6, lr=0.1,
              xgb_init=None, seed=42):
    model = xgb.XGBRegressor(
        n_estimators=n_estimators, max_depth=max_depth, learning_rate=lr,
        subsample=0.8, colsample_bytree=0.8, reg_alpha=0.1, reg_lambda=1.0,
        random_state=seed, n_jobs=-1, verbosity=0,
    )
    model.fit(X_train, y_train, xgb_model=xgb_init, verbose=False)
    return model

# ============================================================
# Main
# ============================================================
print("=" * 60)
print("Real permutation test (200 runs, 5-fold CV)")
print("=" * 60)

pre_path = os.path.join(DATA, "mp_pretrain_binary.csv")
sbx_path = os.path.join(DATA, "mp_sbx_binary.csv")
df_pre_raw = pd.read_csv(pre_path)
df_sbx_raw = pd.read_csv(sbx_path)
print(f"Pretrain raw: {len(df_pre_raw)}")
print(f"Sb-X raw: {len(df_sbx_raw)}")

df_pre = build_pretrain_dataset(df_pre_raw)
df_sbx = build_sbx_dataset(df_sbx_raw)
print(f"Pretrain features: {len(df_pre)}")
print(f"Sb-X features: {len(df_sbx)}")

X_pre = df_pre[FEATURE_NAMES_16].values
y_pre = df_pre["E_form"].values
X_sbx = df_sbx[FEATURE_NAMES_16].values
y_sbx = df_sbx["E_form"].values

print("\nTraining pre-train model...")
pre_model = train_xgb(X_pre, y_pre, n_estimators=300, max_depth=6, lr=0.1, seed=SEED)

with open(os.path.join(OUT, "dft_results.json"), "r", encoding="utf-8") as f:
    R = json.load(f)
real_r2 = R["finetune"]["transfer_15feat"]["r2_loeo"]
print(f"Real model LOEO R2 = {real_r2:.4f}")

print("\nRunning 200 permutation tests (5-fold CV)...")
perm_r2_list = []
kf = KFold(n_splits=5, shuffle=True, random_state=SEED)

for i in range(200):
    y_perm = np.random.permutation(y_sbx)
    fold_r2 = []
    for train_idx, test_idx in kf.split(X_sbx):
        X_tr, X_te = X_sbx[train_idx], X_sbx[test_idx]
        y_tr, y_te = y_perm[train_idx], y_perm[test_idx]
        model = train_xgb(X_tr, y_tr, n_estimators=200, max_depth=4, lr=0.1,
                          xgb_init=pre_model, seed=SEED)
        pred = model.predict(X_te)
        fold_r2.append(r2_score(y_te, pred))
    mean_r2 = np.mean(fold_r2)
    perm_r2_list.append(mean_r2)
    if (i + 1) % 20 == 0:
        print(f"  {i+1}/200 done, mean={np.mean(perm_r2_list):.4f}")

perm_r2_arr = np.array(perm_r2_list)
p_value = float(np.mean(perm_r2_arr >= real_r2))
print(f"\nPermutation test results:")
print(f"  mean = {np.mean(perm_r2_arr):.4f}")
print(f"  std = {np.std(perm_r2_arr):.4f}")
print(f"  min = {np.min(perm_r2_arr):.4f}")
print(f"  max = {np.max(perm_r2_arr):.4f}")
print(f"  p = {p_value:.4f} ({np.sum(perm_r2_arr >= real_r2)}/200 >= real)")

np.save(os.path.join(OUT, "permutation_r2_real.npy"), perm_r2_arr)
with open(os.path.join(OUT, "permutation_results_real.json"), "w", encoding="utf-8") as f:
    json.dump({
        "n_permutations": 200,
        "perm_r2_mean": float(np.mean(perm_r2_arr)),
        "perm_r2_std": float(np.std(perm_r2_arr)),
        "perm_r2_min": float(np.min(perm_r2_arr)),
        "perm_r2_max": float(np.max(perm_r2_arr)),
        "real_r2_loeo": float(real_r2),
        "p_value": p_value,
        "perm_r2_list": [float(v) for v in perm_r2_arr],
    }, f, indent=2)
print("  Saved: permutation_r2_real.npy / permutation_results_real.json")

print("\nPlotting histogram with real 200 values...")
fig, ax = plt.subplots(figsize=(9, 6))
ax.hist(perm_r2_arr, bins=30, color="#A6A6A6", alpha=0.8,
        edgecolor="black", linewidth=0.5,
        label=f"Permuted $R^2$ (200 runs)")
ax.axvline(x=real_r2, color="red", linewidth=2.5, linestyle="--",
           label=f"Real model $R^2$={real_r2:.4f}")
ax.set_xlabel("$R^2$ (5-fold CV)", fontsize=20)
ax.set_ylabel("Frequency", fontsize=20)
p_label = max(p_value, 0.005)
ax.set_title(f"Permutation Test (p < {p_label:.3f})", fontsize=21, fontweight="bold")
ax.legend(fontsize=16)
ax.tick_params(axis="both", labelsize=14)
ax.grid(axis="y", alpha=0.2, linestyle=":")
ax.text(0.02, 0.95, f"Total runs: {len(perm_r2_arr)}", transform=ax.transAxes,
        fontsize=13, va="top", ha="left",
        bbox=dict(boxstyle="round,pad=0.3", facecolor="white", alpha=0.8))
plt.tight_layout()
plt.savefig(os.path.join(OUT, "fig2e_permutation_real.png"), dpi=DPI, bbox_inches="tight")
plt.close()
print("  Saved: fig2e_permutation_real.png")
print("\n" + "=" * 60)
print("Done!")
print("=" * 60)
