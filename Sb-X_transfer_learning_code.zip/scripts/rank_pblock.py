# -*- coding: utf-8 -*-
"""对全部16种p区元素统一预测、统一评分、统一排序"""
import os, importlib.util, json
import numpy as np
import pandas as pd

_HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(_HERE, "..", "results")
OUT_DIR = OUT
DATA = os.path.join(_HERE, "..", "data")
os.makedirs(OUT, exist_ok=True)

# 加载pipeline
_spec = importlib.util.spec_from_file_location("pipeline", os.path.join(OUT, "run_pipeline_dft.py"))
_pipe = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_pipe)

FEATURES = ["epsilon","dchi","dm","dTm","c","dI","dK","VEC",
            "epsilon2","dchi2","dm2","epsilon_c","dchi_c","dm_c",
            "dH_mix","dS_mix"]

df_pre = _pipe.build_pretrain_dataset(pd.read_csv(os.path.join(DATA, "mp_pretrain_binary.csv")))
df_sbx = _pipe.build_sbx_dataset(pd.read_csv(os.path.join(DATA, "mp_sbx_binary.csv")))

# 训练完整迁移模型
pre_model = _pipe.train_xgb(df_pre[FEATURES].values, df_pre["E_form"].values,
                            n_estimators=300, max_depth=6, lr=0.1, seed=42)
ft_model = _pipe.train_xgb(df_sbx[FEATURES].values, df_sbx["E_sub"].values,
                           n_estimators=200, max_depth=4, lr=0.1, xgb_init=pre_model, seed=42)

# 全部16种p区元素
p_block = ["P","As","Se","Ge","Si","B","C","N","S","Bi","Sn","Al","Ga","In","Tl","Pb"]
in_train = set(df_sbx["elem_b"].values)

# 浓度点（用于外推元素）
conc_list = [0.05, 0.08, 0.10, 0.15, 0.20, 0.25, 0.30]

rows = []
for elem in p_block:
    if elem in in_train:
        # 训练集内：用DFT值和LOEO预测
        sub = df_sbx[df_sbx["elem_b"] == elem]
        e_dft = sub["E_sub"].mean()
        # 用完整模型预测（与外推元素一致）
        preds = []
        for _, r in sub.iterrows():
            x = r[FEATURES].values.reshape(1, -1)
            preds.append(float(ft_model.predict(x)[0]))
        e_pred = np.mean(preds)
        row = sub.iloc[0]
        eps, dchi = float(row["epsilon"]), float(row["dchi"])
        n = len(sub)
        source = "DFT"
    else:
        # 训练集外：用完整模型在多浓度下预测
        preds = []
        eps_list, dchi_list = [], []
        for c in conc_list:
            desc = _pipe.compute_descriptors_for_binary("Sb", elem, c)
            x = np.array([[desc[f] for f in FEATURES]])
            preds.append(float(ft_model.predict(x)[0]))
            eps_list.append(desc["epsilon"])
            dchi_list.append(desc["dchi"])
        e_dft = np.nan
        e_pred = np.mean(preds)
        eps = np.mean(eps_list)
        dchi = np.mean(dchi_list)
        n = len(conc_list)
        source = "extrapolated"

    # 多约束评分（与fix_ablation.py一致）
    score = -e_pred - abs(eps - 0.15) * 2.0 - abs(dchi - 0.3) * 1.5

    rows.append({
        "element": elem,
        "source": source,
        "n": n,
        "E_DFT": round(e_dft, 3) if not np.isnan(e_dft) else None,
        "E_pred": round(e_pred, 3),
        "epsilon": round(eps, 3),
        "dchi": round(dchi, 3),
        "score": round(score, 3),
    })

df_rank = pd.DataFrame(rows).sort_values("score", ascending=False).reset_index(drop=True)
df_rank.index = df_rank.index + 1
print(df_rank.to_string())

df_rank.to_csv(os.path.join(OUT, "pblock_ranking_unified.csv"), index=True, index_label="rank", encoding="utf-8-sig")
print("\n已保存: pblock_ranking_unified.csv")
