# -*- coding: utf-8 -*-
"""统一基线超参数和size ablation/MMD，更新 fixed_results.json"""
import os, json, importlib.util
import numpy as np
import pandas as pd
from sklearn.metrics import r2_score, mean_absolute_error
from sklearn.kernel_ridge import KernelRidge
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
import xgboost as xgb

_HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(_HERE, "..", "results")
OUT_DIR = OUT
DATA = os.path.join(_HERE, "..", "data")
os.makedirs(OUT, exist_ok=True)
SEED = 42
np.random.seed(SEED)

df_pre_raw = pd.read_csv(os.path.join(DATA, "mp_pretrain_binary.csv"))
df_sbx = pd.read_csv(os.path.join(DATA, "mp_sbx_binary.csv"))
sbx_ids = set(df_sbx["material_id"].values)
df_pre_clean = df_pre_raw[~df_pre_raw["material_id"].isin(sbx_ids)].copy()

spec = importlib.util.spec_from_file_location("pipeline", os.path.join(OUT, "Code_S1_pipeline.py"))
pipe = importlib.util.module_from_spec(spec); spec.loader.exec_module(pipe)
FEATURES = ["epsilon","dchi","dm","dTm","c","dI","dK","VEC",
            "epsilon2","dchi2","dm2","epsilon_c","dchi_c","dm_c","dH_mix","dS_mix"]
df_pre = pipe.build_pretrain_dataset(df_pre_clean)
df_sbx_feat = pipe.build_sbx_dataset(df_sbx)
X_pre = df_pre[FEATURES].values; y_pre = df_pre["E_form"].values
X_sbx = df_sbx_feat[FEATURES].values; y_sbx = df_sbx_feat["E_sub"].values
elem_sbx = df_sbx_feat["elem_b"].values
unique_elems = sorted(set(elem_sbx))

def loeo_loop(model_fn, X=None):
    Xuse = X_sbx if X is None else X
    preds = np.zeros(len(y_sbx))
    for e in unique_elems:
        tm = elem_sbx == e; trm = ~tm
        m = model_fn()
        m.fit(Xuse[trm], y_sbx[trm]); preds[tm] = m.predict(Xuse[tm])
    return preds

# ---- KRR: alpha=1.0, gamma=0.1, standardized (match rerun_fixed) ----
scaler = StandardScaler(); X_scaled = scaler.fit_transform(X_sbx)
krr_pred = loeo_loop(lambda: KernelRidge(kernel="rbf", alpha=1.0, gamma=0.1), X_scaled)
krr_r2, krr_mae = r2_score(y_sbx, krr_pred), mean_absolute_error(y_sbx, krr_pred)
print(f"KRR: R2={krr_r2:.4f}, MAE={krr_mae:.4f}")

# ---- RF: n=200, depth=8 (match rerun_fixed) ----
rf_pred = loeo_loop(lambda: RandomForestRegressor(n_estimators=200, max_depth=8,
                                                    random_state=SEED, n_jobs=-1))
rf_r2, rf_mae = r2_score(y_sbx, rf_pred), mean_absolute_error(y_sbx, rf_pred)
print(f"RF: R2={rf_r2:.4f}, MAE={rf_mae:.4f}")

# ---- Size ablation: nested sampling (re-seed per size) ----
print("\nSize ablation (nested re-seed):")
size_ablation = {}
for label, n in [("0k",0),("2k",2000),("6k",6000),("12k",len(X_pre))]:
    if n == 0:
        # direct LOEO
        preds = loeo_loop(lambda: xgb.XGBRegressor(
            n_estimators=200, max_depth=4, learning_rate=0.1, subsample=0.8,
            colsample_bytree=0.8, reg_alpha=0.1, reg_lambda=1.0,
            random_state=SEED, verbosity=0, n_jobs=-1))
    else:
        rng = np.random.RandomState(SEED)  # re-seed per size => nested
        idx_sub = rng.choice(len(X_pre), min(n, len(X_pre)), replace=False)
        pm = pipe.train_xgb(X_pre[idx_sub], y_pre[idx_sub], n_estimators=300,
                            max_depth=6, lr=0.1, seed=SEED)
        preds = np.zeros(len(y_sbx))
        for e in unique_elems:
            tm = elem_sbx == e; trm = ~tm
            m = pipe.train_xgb(X_sbx[trm], y_sbx[trm], n_estimators=200, max_depth=4,
                                lr=0.1, xgb_init=pm, seed=SEED)
            preds[tm] = m.predict(X_sbx[tm])
    size_ablation[label] = {"r2_loeo": float(r2_score(y_sbx, preds)),
                             "mae_loeo": float(mean_absolute_error(y_sbx, preds))}
    print(f"  {label}: R2={size_ablation[label]['r2_loeo']:.4f}")

# ---- MMD: standardized, Gaussian sigma=2 ----
def mmd2(X, Y, sigma=2.0):
    def k(a,b):
        d2 = ((a[:,None,:]-b[None,:,:])**2).sum(axis=2)
        return np.exp(-d2/(2*sigma**2))
    return float(k(X,X).mean()+k(Y,Y).mean()-2*k(X,Y).mean())

sc_mmd = StandardScaler()
Xp_s = sc_mmd.fit_transform(X_pre); Xs_s = sc_mmd.transform(X_sbx)
rng = np.random.RandomState(SEED)
pre_sub = Xp_s[rng.choice(len(Xp_s), 2000, replace=False)]
mmd_cross = mmd2(pre_sub, Xs_s)
mmd_pre_int = mmd2(pre_sub[:1000], pre_sub[1000:])
p = np.random.RandomState(SEED).permutation(len(Xs_s)); h=len(Xs_s)//2
mmd_sbx_int = mmd2(Xs_s[p[:h]], Xs_s[p[h:]])
mmd = {"cross": mmd_cross, "pretrain_internal": mmd_pre_int, "sbx_internal": mmd_sbx_int,
       "sigma": 2.0, "standardized": True}
print(f"\nMMD (standardized): cross={mmd_cross:.4f}, pre_int={mmd_pre_int:.4f}, sbx_int={mmd_sbx_int:.4f}")

# ---- Update fixed_results.json ----
with open(os.path.join(OUT,"fixed_results.json"),"r",encoding="utf-8") as f:
    results = json.load(f)
results["finetune"]["krr"] = {"r2_loeo": krr_r2, "mae_loeo": krr_mae}
results["finetune"]["rf"] = {"r2_loeo": rf_r2, "mae_loeo": rf_mae}
results["size_ablation"] = size_ablation
results["mmd"] = mmd
with open(os.path.join(OUT,"fixed_results.json"),"w",encoding="utf-8") as f:
    json.dump(results, f, indent=2, ensure_ascii=False, default=str)

print("\n=== FINAL UNIFIED NUMBERS ===")
ft = results["finetune"]
for k in ["concentration_only","krr","rf","gnn","16_features_direct","transfer_16feat","18_features_leak"]:
    print(f"  {k}: {ft[k]}")
print(f"  size_ablation: {size_ablation}")
print(f"  mmd: {mmd}")
