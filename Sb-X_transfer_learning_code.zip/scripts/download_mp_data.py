# -*- coding: utf-8 -*-
"""
路线1第一步：从Materials Project下载真实DFT数据（修正版v2）
正确处理弹性模量dict格式
"""
import os
import pandas as pd
import numpy as np
from mp_api.client import MPRester

# Materials Project API key. Get your own free key at
# https://materialsproject.org/api and set it as the MP_API_KEY
# environment variable before running this script:
#   Linux/macOS:  export MP_API_KEY="your-key"
#   Windows:      set MP_API_KEY=your-key
MP_API_KEY = os.environ.get("MP_API_KEY", "")
if not MP_API_KEY:
    raise RuntimeError(
        "MP_API_KEY environment variable is not set. Obtain a free key from "
        "https://materialsproject.org/api and set MP_API_KEY before running."
    )
_HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(_HERE, "..", "results")
OUT_DIR = OUT
DATA = os.path.join(_HERE, "..", "data")
os.makedirs(OUT, exist_ok=True)

SUMMARY_FIELDS = [
    "material_id", "formula_pretty",
    "formation_energy_per_atom", "energy_above_hull",
    "volume", "density", "nsites",
    "elements", "nelements",
    "band_gap", "is_metal",
    "bulk_modulus", "shear_modulus",
    "symmetry", "composition",
]


def extract_modulus(mod):
    """从dict中提取VRH值"""
    if mod is None:
        return np.nan
    if isinstance(mod, dict):
        return float(mod.get("vrh", mod.get("VRH", np.nan)))
    try:
        return float(mod)
    except:
        return np.nan


def docs_to_df(docs):
    """将MP docs转为DataFrame"""
    rows = []
    for d in docs:
        g_vrh = extract_modulus(d.shear_modulus)
        k_vrh = extract_modulus(d.bulk_modulus)

        elem_list = [str(e) for e in d.elements] if d.elements else []

        sb_frac = np.nan
        dopant_frac = np.nan
        other_element = ""
        if d.composition is not None:
            try:
                amt = d.composition.get_el_amt_dict()
                total = sum(amt.values())
                if "Sb" in amt and len(amt) == 2:
                    sb_frac = amt["Sb"] / total
                    other_element = [k for k in amt if k != "Sb"][0]
                    dopant_frac = 1.0 - sb_frac
            except:
                pass

        rows.append({
            "material_id": str(d.material_id),
            "formula": d.formula_pretty,
            "formation_energy_per_atom": float(d.formation_energy_per_atom) if d.formation_energy_per_atom is not None else np.nan,
            "energy_above_hull": float(d.energy_above_hull) if d.energy_above_hull is not None else np.nan,
            "volume": float(d.volume) if d.volume is not None else np.nan,
            "density": float(d.density) if d.density is not None else np.nan,
            "nsites": int(d.nsites) if d.nsites is not None else np.nan,
            "elements": ",".join(elem_list),
            "band_gap": float(d.band_gap) if d.band_gap is not None else np.nan,
            "is_metal": bool(d.is_metal) if d.is_metal is not None else np.nan,
            "G_VRH": g_vrh,
            "K_VRH": k_vrh,
            "other_element": other_element,
            "sb_fraction": sb_frac,
            "dopant_fraction": dopant_frac,
        })
    return pd.DataFrame(rows)


def download_pretrain(mpr):
    """下载二元合金预训练集"""
    print("=" * 60)
    print("下载预训练集：二元合金DFT数据...")
    print("=" * 60)

    all_docs = []
    seen = set()

    print("查询 e_above_hull <= 0.1 eV/atom ...")
    try:
        docs = mpr.materials.summary.search(
            num_elements=2,
            energy_above_hull=(None, 0.1),
            fields=SUMMARY_FIELDS,
            chunk_size=1000,
        )
        for d in docs:
            mid = str(d.material_id)
            if mid not in seen:
                seen.add(mid)
                all_docs.append(d)
        print(f"  获取 {len(docs)} 条，去重后 {len(all_docs)} 条")
    except Exception as e:
        print(f"  查询出错: {e}")

    if len(all_docs) < 1200:
        print(f"当前 {len(all_docs)} < 1200，放宽到 e_above_hull <= 0.5 ...")
        try:
            docs2 = mpr.materials.summary.search(
                num_elements=2,
                energy_above_hull=(None, 0.5),
                fields=SUMMARY_FIELDS,
                chunk_size=1000,
            )
            for d in docs2:
                mid = str(d.material_id)
                if mid not in seen:
                    seen.add(mid)
                    all_docs.append(d)
            print(f"  第二批后总计 {len(all_docs)} 条")
        except Exception as e:
            print(f"  第二批出错: {e}")

    df = docs_to_df(all_docs)
    df = df.dropna(subset=["formation_energy_per_atom"])
    df = df.drop_duplicates(subset=["material_id"])
    df = df[df["elements"].str.split(",").apply(len) == 2]
    df = df.reset_index(drop=True)

    outpath = os.path.join(OUT_DIR, "mp_pretrain_binary.csv")
    df.to_csv(outpath, index=False, encoding="utf-8-sig")
    print(f"\n预训练集保存: {outpath}")
    print(f"  总计 {len(df)} 条二元合金DFT数据")
    print(f"  形成能范围: [{df.formation_energy_per_atom.min():.4f}, {df.formation_energy_per_atom.max():.4f}] eV/atom")
    print(f"  含弹性模量: {df.G_VRH.notna().sum()} 条")
    return df


def download_sbx(mpr):
    """下载Sb-X二元合金"""
    print("\n" + "=" * 60)
    print("下载Sb-X二元合金DFT数据...")
    print("=" * 60)

    all_docs = []
    seen = set()

    print("查询含Sb的二元体系 e_above_hull <= 0.1 ...")
    try:
        docs = mpr.materials.summary.search(
            elements=["Sb"],
            num_elements=2,
            energy_above_hull=(None, 0.1),
            fields=SUMMARY_FIELDS,
            chunk_size=1000,
        )
        for d in docs:
            mid = str(d.material_id)
            if mid not in seen:
                seen.add(mid)
                all_docs.append(d)
        print(f"  获取 {len(docs)} 条，去重后 {len(all_docs)} 条")
    except Exception as e:
        print(f"  查询出错: {e}")

    if len(all_docs) < 100:
        print("放宽到 e_above_hull <= 0.5 ...")
        try:
            docs2 = mpr.materials.summary.search(
                elements=["Sb"],
                num_elements=2,
                energy_above_hull=(None, 0.5),
                fields=SUMMARY_FIELDS,
                chunk_size=1000,
            )
            for d in docs2:
                mid = str(d.material_id)
                if mid not in seen:
                    seen.add(mid)
                    all_docs.append(d)
            print(f"  第二批后总计 {len(all_docs)} 条")
        except Exception as e:
            print(f"  第二批出错: {e}")

    df = docs_to_df(all_docs)
    df = df.dropna(subset=["formation_energy_per_atom"])
    df = df.drop_duplicates(subset=["material_id"])
    df = df[df["other_element"] != ""]
    df = df.reset_index(drop=True)

    outpath = os.path.join(OUT_DIR, "mp_sbx_binary.csv")
    df.to_csv(outpath, index=False, encoding="utf-8-sig")
    print(f"\nSb-X数据集保存: {outpath}")
    print(f"  总计 {len(df)} 条Sb-X二元DFT数据")
    if len(df) > 0:
        print(f"  涉及元素: {sorted(df.other_element.unique())}")
        for elem, cnt in df.other_element.value_counts().items():
            print(f"    Sb-{elem}: {cnt} 条")
    return df


def download_elements(mpr):
    """下载纯元素参考态"""
    print("\n" + "=" * 60)
    print("下载纯元素参考态能量...")
    print("=" * 60)

    elems = ["Sb","Si","N","C","B","P","As","Se","Ge","Ag","Sn",
             "Al","In","Ga","Bi","Te","S","Li","Be","O","F","Na","Mg",
             "K","Ca","Sc","Ti","V","Cr","Mn","Fe","Co","Ni","Cu","Zn",
             "Br","Rb","Sr","Y","Zr","Nb","Mo","Ru","Rh","Pd","Cd",
             "Cs","Ba","Hf","Ta","W","Re","Os","Ir","Pt","Au","Hg","Tl","Pb",
             "La","Ce","Pr","Nd","Sm","Eu","Gd","Tb","Dy","Ho","Er","Tm","Yb","Lu"]

    rows = []
    for elem in set(elems):
        try:
            docs = mpr.materials.summary.search(
                elements=[elem], num_elements=1,
                fields=["material_id","formula_pretty","energy_per_atom",
                        "formation_energy_per_atom","volume","density"],
                chunk_size=10,
            )
            if docs:
                best = min(docs, key=lambda d: d.energy_per_atom if d.energy_per_atom else float("inf"))
                rows.append({
                    "element": elem,
                    "material_id": str(best.material_id),
                    "energy_per_atom": float(best.energy_per_atom) if best.energy_per_atom else np.nan,
                })
                print(f"  {elem}: {best.material_id}, E={best.energy_per_atom:.4f} eV/atom")
        except Exception as e:
            print(f"  {elem}: 失败 - {e}")

    df = pd.DataFrame(rows)
    outpath = os.path.join(OUT_DIR, "mp_pure_elements.csv")
    df.to_csv(outpath, index=False, encoding="utf-8-sig")
    print(f"纯元素参考态保存: {outpath}, 共 {len(df)} 种")
    return df


if __name__ == "__main__":
    with MPRester(MP_API_KEY, timeout=120) as mpr:
        df_pre = download_pretrain(mpr)
        df_sbx = download_sbx(mpr)
        df_elem = download_elements(mpr)
    print("\n" + "=" * 60)
    print("全部数据下载完成！")
    print(f"  预训练集: {len(df_pre)} 条")
    print(f"  Sb-X微调集: {len(df_sbx)} 条")
    print(f"  纯元素参考: {len(df_elem)} 条")
    print("=" * 60)
