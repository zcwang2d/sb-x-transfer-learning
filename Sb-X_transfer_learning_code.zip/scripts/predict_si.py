# -*- coding: utf-8 -*-
"""用训练好的模型预测Si-Sb等训练集中没有的元素，并与实验文献对比"""
import os, json
import numpy as np
import pandas as pd
import xgboost as xgb
import importlib.util

_HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(_HERE, "..", "results")
OUT_DIR = OUT
DATA = os.path.join(_HERE, "..", "data")
os.makedirs(OUT, exist_ok=True)
_spec = importlib.util.spec_from_file_location("pipeline", os.path.join(OUT, "run_pipeline_dft.py"))
_pipe = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_pipe)
ELEMENT_PROPS = _pipe.ELEMENT_PROPS
compute_descriptors = _pipe.compute_descriptors_for_binary
train_xgb = _pipe.train_xgb

FEATURES = ["epsilon","dchi","dm","dTm","c","dI","dK","VEC",
            "epsilon2","dchi2","dm2","epsilon_c","dchi_c","dm_c",
            "dH_mix","dS_mix"]

# 加载数据
df_pre = _pipe.build_pretrain_dataset(pd.read_csv(os.path.join(DATA, "mp_pretrain_binary.csv")))
df_sbx = _pipe.build_sbx_dataset(pd.read_csv(os.path.join(DATA, "mp_sbx_binary.csv")))

X_pre = df_pre[FEATURES].values
y_pre = df_pre["E_form"].values
X_sbx = df_sbx[FEATURES].values
y_sbx = df_sbx["E_sub"].values

# 训练迁移模型
print("训练预训练模型...")
pre_model = train_xgb(X_pre, y_pre, n_estimators=300, max_depth=6, lr=0.1, seed=42)
print("微调...")
ft_model = train_xgb(X_sbx, y_sbx, n_estimators=200, max_depth=4, lr=0.1, xgb_init=pre_model, seed=42)

# 预测训练集中没有的元素
print("\n=== 对训练集中未出现元素的预测 ===")
missing_elems = ['Si','N','C','B','P','O','F','Be']
for elem in missing_elems:
    if elem not in ELEMENT_PROPS:
        print(f"{elem}: not in ELEMENT_PROPS")
        continue
    # 预测多个浓度（5–30 at% 稀掺杂网格，与正文一致）
    concs = [0.05, 0.0864, 0.10, 0.15, 0.20, 0.25, 0.30]
    preds = []
    for c in concs:
        desc = compute_descriptors("Sb", elem, c)
        if desc is None: continue
        x = np.array([[desc[f] for f in FEATURES]])
        p = ft_model.predict(x)[0]
        preds.append((c, p))
    print(f"\n{elem}-Sb:")
    for c, p in preds:
        print(f"  c={c:.4f}: E_form_pred = {p:.3f} eV/atom")
    # 描述符
    desc = compute_descriptors("Sb", elem, 0.0864)
    if desc:
        print(f"  描述符(c=8.64%): epsilon={desc['epsilon']:.3f}, dchi={desc['dchi']:.3f}, "
              f"dH_mix={desc['dH_mix']:.1f} kJ/mol, dTm={desc['dTm']:.1f}, VEC={desc['VEC']:.2f}")

# 对训练集中已有元素，对比DFT和预测
print("\n=== 训练集中已有元素的DFT vs 预测对比 ===")
for elem in ['Ge','In','Ga','Se','Te','Bi','Sn','Al','S','As']:
    sub = df_sbx[df_sbx['elem_b']==elem]
    if len(sub)==0: continue
    x = sub[FEATURES].values
    preds = ft_model.predict(x)
    dft = sub['E_sub'].values
    print(f"{elem}: n={len(sub)}, DFT均值={dft.mean():.3f}, 预测均值={preds.mean():.3f}, "
          f"MAE={np.abs(dft-preds).mean():.3f}")
