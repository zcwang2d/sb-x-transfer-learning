# -*- coding: utf-8 -*-
"""
模型优化真实LOEO对比（协议与revise_rerun完全一致：源排除Sb, 预训练300/d6, LOEO续训200/d4, seed42原始顺序）
 B0   : 基线16特征 全源域(应=0.864/0.167, 校验协议)
 AUG  : 16 + 6个pymatgen增强元素表示特征
 SRCp : 源域只保留含p-block元素的二元(化学近邻聚焦)
 SRCknn: 源域按到目标域的标准化距离取最近6000(相关6k vs 随机6k)
 AUGp : 增强 + p-block近邻源域(组合)
并报 p区16候选子集 MAE；最后做LOEO交叉拟合conformal区间覆盖率
"""
import os, importlib.util, warnings
import numpy as np, pandas as pd
warnings.filterwarnings("ignore")
from pymatgen.core import Element
from sklearn.metrics import r2_score, mean_absolute_error
from sklearn.preprocessing import StandardScaler

HERE=os.path.dirname(os.path.abspath(__file__))
DATA=os.path.join(HERE,"..","data")
spec=importlib.util.spec_from_file_location("pipe",os.path.join(HERE,"Code_S1_pipeline.py"))
pipe=importlib.util.module_from_spec(spec); spec.loader.exec_module(pipe)
FEAT=pipe.FEATURE_NAMES_16
PBLOCK=["P","As","Se","Ge","Si","B","C","N","S","Bi","Sn","Al","Ga","In","Tl","Pb"]
SEED=42

# ---------- 数据(与revise_rerun一致) ----------
pre_raw=pd.read_csv(os.path.join(DATA,"mp_pretrain_binary.csv"))
sbx_raw=pd.read_csv(os.path.join(DATA,"mp_sbx_binary.csv"))
sbx_ids=set(sbx_raw.material_id)
pre=pipe.build_pretrain_dataset(pre_raw[~pre_raw.material_id.isin(sbx_ids)])
sbx=pipe.build_sbx_dataset(sbx_raw)

# ---------- ① pymatgen 增强特征(元素对缓存) ----------
AUG=["dMend","dRow","dGroup","dEAff","dMVol","dKth"]
_cache={}
def aug_for(ea,eb):
    key=(ea,eb)
    if key in _cache: return _cache[key]
    A,B=Element(ea),Element(eb)
    v={
      "dMend":abs(B.mendeleev_no-A.mendeleev_no),
      "dRow":abs(B.row-A.row),
      "dGroup":abs((B.group or 0)-(A.group or 0)),
      "dEAff":abs((B.electron_affinity or 0)-(A.electron_affinity or 0)),
      "dMVol":abs(B.molar_volume-A.molar_volume)/ (A.molar_volume+1e-9),
      "dKth":abs((B.thermal_conductivity or 0)-(A.thermal_conductivity or 0))/ (A.thermal_conductivity+1e-9),
    }
    _cache[key]=v; return v
def attach_aug(df):
    mat=np.zeros((len(df),len(AUG)))
    for i,(_,r) in enumerate(df.iterrows()):
        v=aug_for(r.elem_a,r.elem_b)
        mat[i]=[v[a] for a in AUG]
    for j,a in enumerate(AUG): df[a]=mat[:,j]
    return df
pre=attach_aug(pre); sbx=attach_aug(sbx)
ALLFEAT=FEAT+AUG

yp_all=pre.E_form.values; yt=sbx.E_sub.values; et=sbx.elem_b.values
p_mask=np.isin(et,PBLOCK)

def loeo(pre_model,Xtr):
    pred=np.zeros(len(yt))
    for e in sorted(set(et)):
        te=et==e; tr=~te
        m=pipe.train_xgb(Xtr[tr],yt[tr],n_estimators=200,max_depth=4,lr=0.1,xgb_init=pre_model,seed=SEED)
        pred[te]=m.predict(Xtr[te])
    return pred
def report(name,pre_X,feat,tagX=None):
    Xt=sbx[feat].values
    pm=pipe.train_xgb(pre_X,yp_all if tagX is None else tagX,n_estimators=300,max_depth=6,lr=0.1,seed=SEED)
    pr=loeo(pm,Xt)
    r2=r2_score(yt,pr); mae=mean_absolute_error(yt,pr)
    mae_p=mean_absolute_error(yt[p_mask],pr[p_mask])
    print("  %-8s 全局 R2=%.4f MAE=%.4f | p区16候选 MAE=%.4f (n=%d)"%(name,r2,mae,mae_p,p_mask.sum()))
    return pr,r2,mae,mae_p

print("="*70); print("源域=%d  目标=%d  p区候选点=%d"%(len(pre),len(sbx),p_mask.sum())); print("="*70)
res={}
# B0
pr,r2,mae,mp=report("B0基线",pre[FEAT].values,FEAT); res["B0"]=(r2,mae,mp)
# AUG
_,r2,mae,mp=report("AUG增强",pre[ALLFEAT].values,ALLFEAT); res["AUG"]=(r2,mae,mp)
# SRCp: 含p-block的源
def is_pb(e):
    try:return Element(e).group is not None and Element(e).group>=13
    except:return False
pmask_src=np.array([is_pb(a) or is_pb(b) for a,b in zip(pre.elem_a,pre.elem_b)])
pre_p=pre[pmask_src]; print("  [SRCp 含p-block源域条数=%d]"%len(pre_p))
_,r2,mae,mp=report("SRCp近邻",pre_p[FEAT].values,FEAT,tagX=pre_p.E_form.values); res["SRCp"]=(r2,mae,mp)
# SRCknn: 标准化空间到目标中心最近6000
sc=StandardScaler().fit(pre[FEAT].values)
Ps=sc.transform(pre[FEAT].values); Ts=sc.transform(sbx[FEAT].values)
center=Ts.mean(0); d=np.linalg.norm(Ps-center,axis=1)
knn_idx=np.argsort(d)[:6000]; pre_k=pre.iloc[knn_idx]
_,r2,mae,mp=report("SRCknn6k",pre_k[FEAT].values,FEAT,tagX=pre_k.E_form.values); res["SRCknn"]=(r2,mae,mp)
# AUG + SRCp
_,r2,mae,mp=report("AUG+p组合",pre_p[ALLFEAT].values,ALLFEAT,tagX=pre_p.E_form.values); res["AUGp"]=(r2,mae,mp)

# ---------- ④ conformal 区间(基于B0 LOEO残差, 交叉拟合: 留出元素用其余残差标定) ----------
print("="*70); print("[④] 交叉拟合conformal预测区间覆盖率(基于B0 LOEO)")
resid=yt-pr
for q in [0.80,0.90,0.95]:
    cover=[]; widths=[]
    for e in sorted(set(et)):
        te=et==e
        cal=np.abs(resid[~te]); h=np.quantile(cal,q)
        cover.append(np.mean(np.abs(resid[te])<=h)); widths.append(2*h)
    print("  名义%.0f%% -> 经验覆盖率 %.3f, 平均半宽 %.3f eV/atom"%(q*100,np.mean(list(cover)),np.mean(widths)/2))

print("\n==== 汇总(全局R2/MAE, p区MAE) ====")
for k,(r2,mae,mp) in res.items(): print("  %-8s R2=%.4f MAE=%.4f pMAE=%.4f"%(k,r2,mae,mp))
