# -*- coding: utf-8 -*-
"""
路线1第三步：物理描述符计算 + 两阶段XGBoost迁移学习（优化版）
- 预训练集用5折CV（12700条LOOCV太慢）
- dH_mix用Miedema物理估算（避免数据泄露）
- Permutation/Bootstrap优化次数
"""
import os, json, re, warnings
import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.model_selection import KFold, LeaveOneOut, LeaveOneGroupOut
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore")
np.random.seed(42)

_HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(_HERE, "..", "results")
OUT_DIR = OUT
DATA = os.path.join(_HERE, "..", "data")
os.makedirs(OUT, exist_ok=True)

# ============================================================
# 元素物理属性表（70+种元素）
# [共价半径Å, Pauling电负性, 原子质量u, 熔点K, 第一电离能eV, 体弹模量GPa, 价电子数]
# ============================================================
ELEMENT_PROPS = {
    "Sb":[1.39,2.05,121.76,903.78,8.608,42.0,5],
    "Si":[1.11,1.90,28.09,1687.0,8.152,97.6,4],
    "N":[0.75,3.04,14.01,63.15,14.534,2.0,5],
    "C":[0.77,2.55,12.01,3823.0,11.260,33.5,4],
    "B":[0.84,2.04,10.81,2349.0,8.298,178.0,3],
    "P":[1.07,2.19,30.97,317.3,10.487,5.1,5],
    "As":[1.19,2.18,74.92,1090.0,9.815,22.0,5],
    "Se":[1.20,2.55,78.96,494.0,9.752,8.3,6],
    "Ge":[1.22,2.01,72.63,1211.4,7.900,75.8,4],
    "Ag":[1.45,1.93,107.87,1234.9,7.576,100.0,11],
    "Sn":[1.39,1.96,118.71,505.1,7.344,53.0,4],
    "Al":[1.21,1.61,26.98,933.5,5.986,76.0,3],
    "In":[1.42,1.78,114.82,429.7,5.786,10.0,3],
    "Ga":[1.22,1.81,69.72,302.9,5.999,56.0,3],
    "Bi":[1.48,2.02,208.98,544.7,7.286,32.0,5],
    "Te":[1.38,2.10,127.60,722.7,9.010,6.5,6],
    "S":[1.02,2.58,32.07,388.4,10.360,7.7,6],
    "Li":[1.34,0.98,6.94,453.7,5.392,11.6,1],
    "Be":[0.90,1.57,9.01,1560.0,9.323,130.0,2],
    "O":[0.73,3.44,16.00,54.8,13.618,1.0,6],
    "F":[0.71,3.98,19.00,53.5,17.423,1.0,7],
    "Na":[1.54,0.93,22.99,371.0,5.139,6.8,1],
    "Mg":[1.30,1.31,24.31,923.0,7.646,45.0,2],
    "K":[1.96,0.82,39.10,336.5,4.341,3.2,1],
    "Ca":[1.74,1.00,40.08,1115.0,6.113,17.0,2],
    "Sc":[1.44,1.36,44.96,1814.0,6.561,57.0,3],
    "Ti":[1.36,1.54,47.87,1941.0,6.828,110.0,4],
    "V":[1.34,1.63,50.94,2183.0,6.746,162.0,5],
    "Cr":[1.39,1.66,52.00,2180.0,6.767,160.0,6],
    "Mn":[1.39,1.55,54.94,1519.0,7.434,120.0,7],
    "Fe":[1.32,1.83,55.85,1811.0,7.902,170.0,8],
    "Co":[1.26,1.88,58.93,1768.0,7.881,180.0,9],
    "Ni":[1.24,1.91,58.69,1728.0,7.640,186.0,10],
    "Cu":[1.32,1.90,63.55,1357.8,7.726,140.0,11],
    "Zn":[1.22,1.65,65.38,692.7,9.394,70.0,12],
    "Br":[1.14,2.96,79.90,265.8,11.814,1.0,7],
    "Rb":[2.11,0.82,85.47,312.6,4.177,2.5,1],
    "Sr":[1.92,0.95,87.62,1050.0,5.695,12.0,2],
    "Y":[1.62,1.22,88.91,1799.0,6.217,41.0,3],
    "Zr":[1.45,1.33,91.22,2128.0,6.634,95.0,4],
    "Nb":[1.34,1.60,92.91,2750.0,6.759,170.0,5],
    "Mo":[1.39,2.16,95.95,2896.0,7.092,230.0,6],
    "Ru":[1.25,2.20,101.07,2607.0,7.361,220.0,8],
    "Rh":[1.25,2.28,102.91,2237.0,7.459,275.0,9],
    "Pd":[1.28,2.20,106.42,1828.0,8.337,180.0,10],
    "Cd":[1.44,1.69,112.41,594.2,8.993,52.0,12],
    "Cs":[2.25,0.79,132.91,301.6,3.894,1.6,1],
    "Ba":[1.98,0.89,137.33,1000.0,5.212,9.0,2],
    "Hf":[1.44,1.30,178.49,2506.0,6.825,110.0,4],
    "Ta":[1.38,1.50,180.95,3290.0,7.550,200.0,5],
    "W":[1.39,2.36,183.84,3695.0,7.864,310.0,6],
    "Re":[1.37,1.90,186.21,3459.0,7.834,370.0,7],
    "Os":[1.28,2.20,190.23,3306.0,8.438,418.0,8],
    "Ir":[1.27,2.20,192.22,2719.0,8.967,355.0,9],
    "Pt":[1.30,2.28,195.08,2041.5,8.959,230.0,10],
    "Au":[1.36,2.54,196.97,1337.3,9.226,173.0,11],
    "Hg":[1.49,2.00,200.59,234.3,10.438,28.5,12],
    "Tl":[1.48,1.62,204.38,577.0,6.108,36.0,3],
    "Pb":[1.47,2.33,207.20,600.6,7.417,46.0,4],
    "La":[1.69,1.10,138.91,1193.0,5.577,24.0,3],
    "Ce":[1.63,1.12,140.12,1068.0,5.539,22.0,4],
    "Pr":[1.66,1.13,140.91,1208.0,5.473,29.0,5],
    "Nd":[1.64,1.14,144.24,1297.0,5.525,32.0,6],
    "Sm":[1.66,1.17,150.36,1345.0,5.644,30.0,8],
    "Eu":[1.68,1.20,151.96,1099.0,5.670,15.0,9],
    "Gd":[1.61,1.20,157.25,1585.0,6.150,38.0,10],
    "Tb":[1.59,1.20,158.93,1629.0,5.864,39.0,11],
    "Dy":[1.59,1.22,162.50,1680.0,5.939,41.0,12],
    "Ho":[1.58,1.23,164.93,1734.0,6.022,40.0,13],
    "Er":[1.57,1.24,167.26,1802.0,6.108,44.0,14],
    "Tm":[1.56,1.25,168.93,1818.0,6.184,45.0,15],
    "Yb":[1.70,1.10,173.05,1097.0,6.254,13.0,16],
    "Lu":[1.56,1.27,174.97,1925.0,5.426,41.0,3],
    "Cl":[0.99,3.16,35.45,171.6,12.968,1.0,7],
    "I":[1.33,2.66,126.90,386.9,10.451,7.7,7],
    "Th":[1.65,1.30,232.04,2023.0,6.307,54.0,4],
    "U":[1.42,1.38,238.03,1405.0,6.194,100.0,6],
    "Np":[1.44,1.36,237.05,917.0,6.266,78.0,7],
    "Pu":[1.50,1.28,244.00,912.5,6.026,42.0,8],
    "Pa":[1.61,1.50,231.04,1845.0,5.890,76.0,5],
}


def get_element_props(elem):
    return ELEMENT_PROPS.get(elem, None)


def compute_descriptors_for_binary(elem_a, elem_b, c_b):
    """
    计算二元合金16个输入物理描述符
    elem_a: 基体元素, elem_b: 掺杂元素, c_b: 掺杂浓度(原子分数)
    """
    pa = get_element_props(elem_a)
    pb = get_element_props(elem_b)
    if pa is None or pb is None:
        return None

    ra, chia, ma, Tma, Ia, Ka, VECa = pa
    rb, chib, mb, Tmb, Ib, Kb, VECb = pb
    c_a = 1.0 - c_b

    # 8个基础错配描述符
    epsilon = abs(rb - ra) / ra
    dchi = abs(chib - chia)
    dm = abs(mb - ma) / ma
    dTm = abs(Tmb - Tma) / Tma
    c = c_b
    dI = abs(Ib - Ia) / Ia
    dK = abs(Kb - Ka) / Ka
    VEC = c_a * VECa + c_b * VECb

    # 3个非线性项
    epsilon2 = epsilon ** 2
    dchi2 = dchi ** 2
    dm2 = dm ** 2

    # 3个浓度交互项
    epsilon_c = epsilon * c_b
    dchi_c = dchi * c_b
    dm_c = dm * c_b

    # 2个热力学描述符
    # ΔS_mix: 理想混合熵
    R = 8.314  # J/(mol·K)
    with np.errstate(divide="ignore", invalid="ignore"):
        dS_mix = -R * (c_a * np.log(c_a + 1e-12) + c_b * np.log(c_b + 1e-12))

    # ΔH_mix: Miedema模型物理估算
    # 简化Miedema: ΔH_mix = 4*cA*cB*Ω, Ω基于电负性差和电子密度
    # Ω ≈ -P * (Δχ)^2, P为经验常数(kJ/mol)
    # 参考Miedema原始工作和高熵合金文献
    P_miedema = 50.0  # kJ/mol, 经验比例常数
    Omega = -P_miedema * dchi ** 2
    dH_mix = 4.0 * c_a * c_b * Omega

    return {
        "epsilon": epsilon, "dchi": dchi, "dm": dm, "dTm": dTm,
        "c": c, "dI": dI, "dK": dK, "VEC": VEC,
        "epsilon2": epsilon2, "dchi2": dchi2, "dm2": dm2,
        "epsilon_c": epsilon_c, "dchi_c": dchi_c, "dm_c": dm_c,
        "dH_mix": dH_mix, "dS_mix": dS_mix,
    }


def build_pretrain_dataset(df_pretrain):
    """从预训练CSV构建特征矩阵"""
    print("构建预训练数据集特征...")
    rows = []
    for _, row in df_pretrain.iterrows():
        elements = str(row["elements"]).split(",")
        if len(elements) != 2:
            continue
        ea, eb = elements[0].strip(), elements[1].strip()
        if ea not in ELEMENT_PROPS or eb not in ELEMENT_PROPS:
            continue
        # 源/目标严格隔离：剔除所有含 Sb 的记录（334 条 Sb-X 化合物只出现在微调集）
        if "Sb" in (ea, eb):
            continue

        formula = row["formula"]
        matches = re.findall(r"([A-Z][a-z]?)(\d*\.?\d*)", formula)
        if len(matches) != 2:
            continue
        (e1, n1), (e2, n2) = matches
        n1 = float(n1) if n1 else 1.0
        n2 = float(n2) if n2 else 1.0
        total = n1 + n2
        c1 = n1 / total
        c2 = n2 / total

        if e1 == ea:
            c_b = c2 if e2 == eb else c1
        else:
            c_b = c1 if e1 == eb else c2
            ea, eb = eb, ea

        desc = compute_descriptors_for_binary(ea, eb, c_b)
        if desc is None:
            continue

        desc["dG"] = abs(float(row["G_VRH"]) - ELEMENT_PROPS[ea][5]) if not pd.isna(row.get("G_VRH", np.nan)) else 0.0
        desc["material_id"] = row["material_id"]
        desc["formula"] = formula
        desc["E_form"] = float(row["formation_energy_per_atom"])
        desc["E_sub"] = float(row["formation_energy_per_atom"])
        desc["e_above_hull"] = float(row["energy_above_hull"])
        desc["elem_a"] = ea
        desc["elem_b"] = eb
        desc["c_b"] = c_b
        rows.append(desc)

    df = pd.DataFrame(rows)
    print(f"  预训练特征集: {len(df)} 条")
    return df


def build_sbx_dataset(df_sbx):
    """从Sb-X CSV构建特征矩阵"""
    print("构建Sb-X微调数据集特征...")
    rows = []
    for _, row in df_sbx.iterrows():
        eb = row["other_element"]
        ea = "Sb"
        if eb not in ELEMENT_PROPS:
            continue
        c_b = float(row["dopant_fraction"])
        if np.isnan(c_b):
            continue

        desc = compute_descriptors_for_binary(ea, eb, c_b)
        if desc is None:
            continue

        desc["dG"] = abs(float(row["G_VRH"]) - ELEMENT_PROPS["Sb"][5]) if not pd.isna(row.get("G_VRH", np.nan)) else 0.0
        desc["material_id"] = row["material_id"]
        desc["formula"] = row["formula"]
        desc["E_form"] = float(row["formation_energy_per_atom"])
        desc["E_sub"] = float(row["formation_energy_per_atom"])
        desc["e_above_hull"] = float(row["energy_above_hull"])
        desc["elem_a"] = ea
        desc["elem_b"] = eb
        desc["c_b"] = c_b
        rows.append(desc)

    df = pd.DataFrame(rows)
    print(f"  Sb-X特征集: {len(df)} 条")
    print(f"  涉及元素: {sorted(df.elem_b.unique())}")
    return df


FEATURE_NAMES_16 = ["epsilon","dchi","dm","dTm","c","dI","dK","VEC",
                    "epsilon2","dchi2","dm2","epsilon_c","dchi_c","dm_c",
                    "dH_mix","dS_mix"]
FEATURE_NAMES_18 = FEATURE_NAMES_16 + ["dG","E_form"]


def train_xgb(X_train, y_train, n_estimators=300, max_depth=5, lr=0.08,
              xgb_init=None, seed=42):
    model = xgb.XGBRegressor(
        n_estimators=n_estimators, max_depth=max_depth, learning_rate=lr,
        subsample=0.8, colsample_bytree=0.8, reg_alpha=0.1, reg_lambda=1.0,
        random_state=seed, n_jobs=-1, verbosity=0,
    )
    model.fit(X_train, y_train, xgb_model=xgb_init, verbose=False)
    return model


def kfold_eval(model_fn, X, y, n_splits=5, seed=42):
    """K折交叉验证（大数据集用）"""
    kf = KFold(n_splits=n_splits, shuffle=True, random_state=seed)
    preds = np.zeros(len(y))
    for tr, te in kf.split(X):
        m = model_fn(X[tr], y[tr], seed=seed)
        preds[te] = m.predict(X[te])
    r2 = r2_score(y, preds)
    mae = mean_absolute_error(y, preds)
    rmse = np.sqrt(mean_squared_error(y, preds))
    return r2, mae, rmse, preds


def loocv_eval(model_fn, X, y, seed=42):
    loo = LeaveOneOut()
    preds = np.zeros(len(y))
    for tr, te in loo.split(X):
        m = model_fn(X[tr], y[tr], seed=seed)
        preds[te] = m.predict(X[te])
    r2 = r2_score(y, preds)
    mae = mean_absolute_error(y, preds)
    rmse = np.sqrt(mean_squared_error(y, preds))
    return r2, mae, rmse, preds


def loeo_eval(model_fn, X, y, groups, seed=42):
    logo = LeaveOneGroupOut()
    preds = np.zeros(len(y))
    for tr, te in logo.split(X, y, groups):
        m = model_fn(X[tr], y[tr], seed=seed)
        preds[te] = m.predict(X[te])
    r2 = r2_score(y, preds)
    mae = mean_absolute_error(y, preds)
    rmse = np.sqrt(mean_squared_error(y, preds))
    return r2, mae, rmse, preds


def run_transfer_learning(df_pre, df_sbx):
    print("\n" + "=" * 60)
    print("两阶段XGBoost迁移学习")
    print("=" * 60)
    results = {}

    # ---- 阶段1：预训练 ----
    print("\n[阶段1] 预训练：二元合金形成能预测（5折CV）...")
    pre_features = FEATURE_NAMES_16  # 16个物理特征
    X_pre = df_pre[pre_features].values
    y_pre = df_pre["E_form"].values
    print(f"  预训练样本: {len(X_pre)}, 特征: {X_pre.shape[1]}")

    def pre_fn(Xtr, ytr, seed=42):
        return train_xgb(Xtr, ytr, n_estimators=300, max_depth=6, lr=0.1, seed=seed)

    r2_pre, mae_pre, rmse_pre, preds_pre = kfold_eval(pre_fn, X_pre, y_pre, n_splits=5)
    print(f"  预训练5折CV: R2={r2_pre:.4f}, MAE={mae_pre:.4f} eV/atom, RMSE={rmse_pre:.4f}")

    pre_model_full = train_xgb(X_pre, y_pre, n_estimators=300, max_depth=6, lr=0.1)
    results["pretrain"] = {"r2_5fold": r2_pre, "mae_5fold": mae_pre,
                           "rmse_5fold": rmse_pre, "n_samples": len(X_pre)}

    # ---- 阶段2：微调 ----
    print("\n[阶段2] 微调：Sb-X替位形成能预测...")
    sbx_features = FEATURE_NAMES_16
    X_sbx = df_sbx[sbx_features].values
    y_sbx = df_sbx["E_sub"].values
    groups_sbx = df_sbx["elem_b"].values
    print(f"  微调样本: {len(X_sbx)}, 特征: {X_sbx.shape[1]}")
    print(f"  元素分组: {dict(df_sbx.elem_b.value_counts())}")

    # 2a. 仅浓度基线
    X_c = df_sbx[["c"]].values
    def conc_fn(Xtr, ytr, seed=42):
        return train_xgb(Xtr, ytr, n_estimators=100, max_depth=2, lr=0.1, seed=seed)
    r2_c, mae_c, _, _ = loocv_eval(conc_fn, X_c, y_sbx)
    r2_loeo_c, mae_loeo_c, _, _ = loeo_eval(conc_fn, X_c, y_sbx, groups_sbx)
    print(f"  仅浓度: LOOCV R2={r2_c:.4f}, MAE={mae_c:.4f}")

    # 2b. 16特征直接训练（不迁移）
    def direct_fn(Xtr, ytr, seed=42):
        return train_xgb(Xtr, ytr, n_estimators=200, max_depth=4, lr=0.1, seed=seed)
    r2_d, mae_d, _, _ = loocv_eval(direct_fn, X_sbx, y_sbx)
    r2_loeo_d, mae_loeo_d, _, _ = loeo_eval(direct_fn, X_sbx, y_sbx, groups_sbx)
    print(f"  16特征直接: LOOCV R2={r2_d:.4f}, MAE={mae_d:.4f}; LOEO R2={r2_loeo_d:.4f}")

    # 2c. 18特征（含dG, E_form）
    X_18 = df_sbx[FEATURE_NAMES_18].values
    def f18_fn(Xtr, ytr, seed=42):
        return train_xgb(Xtr, ytr, n_estimators=200, max_depth=4, lr=0.1, seed=seed)
    r2_18, mae_18, _, _ = loocv_eval(f18_fn, X_18, y_sbx)
    r2_loeo_18, mae_loeo_18, _, _ = loeo_eval(f18_fn, X_18, y_sbx, groups_sbx)
    print(f"  18特征直接: LOOCV R2={r2_18:.4f}, MAE={mae_18:.4f}; LOEO R2={r2_loeo_18:.4f}")

    # 2d. 两阶段迁移学习
    def tl_fn(Xtr, ytr, seed=42):
        return train_xgb(Xtr, ytr, n_estimators=200, max_depth=4, lr=0.1,
                         xgb_init=pre_model_full, seed=seed)
    r2_tl, mae_tl, rmse_tl, preds_tl = loocv_eval(tl_fn, X_sbx, y_sbx)
    r2_loeo_t, mae_loeo_t, rmse_loeo_t, preds_loeo_t = loeo_eval(tl_fn, X_sbx, y_sbx, groups_sbx)
    print(f"  迁移学习: LOOCV R2={r2_tl:.4f}, MAE={mae_tl:.4f}; LOEO R2={r2_loeo_t:.4f}")

    results["finetune"] = {
        "concentration_only": {"r2_loocv": r2_c, "mae_loocv": mae_c,
                               "r2_loeo": r2_loeo_c, "mae_loeo": mae_loeo_c},
        "16_features_direct": {"r2_loocv": r2_d, "mae_loocv": mae_d,
                               "r2_loeo": r2_loeo_d, "mae_loeo": mae_loeo_d},
        "18_features_direct": {"r2_loocv": r2_18, "mae_loocv": mae_18,
                               "r2_loeo": r2_loeo_18, "mae_loeo": mae_loeo_18},
        "transfer_15feat": {"r2_loocv": r2_tl, "mae_loocv": mae_tl, "rmse_loocv": rmse_tl,
                            "r2_loeo": r2_loeo_t, "mae_loeo": mae_loeo_t, "rmse_loeo": rmse_loeo_t},
    }

    # ---- Permutation test（200次，5折CV） ----
    print("\nPermutation test (200次, 5折CV)...")
    perm_r2 = []
    for i in range(200):
        y_perm = np.random.permutation(y_sbx)
        try:
            r2_p, _, _, _ = kfold_eval(tl_fn, X_sbx, y_perm, n_splits=5)
            perm_r2.append(r2_p)
        except:
            perm_r2.append(-999)
    perm_r2 = np.array(perm_r2)
    p_val = float(np.mean(perm_r2 >= r2_tl))
    print(f"  p-value = {p_val:.4f}")
    results["permutation"] = {"p_value": p_val,
                              "perm_r2_mean": float(np.mean(perm_r2)),
                              "perm_r2_std": float(np.std(perm_r2)),
                              "n_permutations": 200}

    # ---- Bootstrap CI（500次） ----
    print("Bootstrap 95% CI (500次)...")
    boot_r2, boot_mae = [], []
    n = len(y_sbx)
    for i in range(500):
        idx = np.random.choice(n, n, replace=True)
        try:
            mb = train_xgb(X_sbx[idx], y_sbx[idx], n_estimators=200, max_depth=4,
                           lr=0.1, xgb_init=pre_model_full)
            pb = mb.predict(X_sbx[idx])
            boot_r2.append(r2_score(y_sbx[idx], pb))
            boot_mae.append(mean_absolute_error(y_sbx[idx], pb))
        except:
            pass
    results["bootstrap"] = {
        "r2_ci": [float(np.percentile(boot_r2, 2.5)), float(np.percentile(boot_r2, 97.5))],
        "mae_ci": [float(np.percentile(boot_mae, 2.5)), float(np.percentile(boot_mae, 97.5))],
        "r2_mean": float(np.mean(boot_r2)), "mae_mean": float(np.mean(boot_mae)),
        "n_bootstrap": 500,
    }
    print(f"  R2 95% CI: [{results['bootstrap']['r2_ci'][0]:.3f}, {results['bootstrap']['r2_ci'][1]:.3f}]")

    # ---- SHAP ----
    print("\nSHAP可解释性分析...")
    try:
        import shap
        final_model = train_xgb(X_sbx, y_sbx, n_estimators=200, max_depth=4,
                                lr=0.1, xgb_init=pre_model_full)
        explainer = shap.TreeExplainer(final_model)
        shap_values = explainer.shap_values(X_sbx)
        mas = np.mean(np.abs(shap_values), axis=0)
        ranking = sorted(zip(sbx_features, mas), key=lambda x: -x[1])
        print("  SHAP排名:")
        for name, val in ranking:
            print(f"    {name}: {val:.6f}")
        results["shap"] = {
            "feature_names": sbx_features,
            "mean_abs_shap": [float(v) for v in mas],
            "ranking": [(n, float(v)) for n, v in ranking],
        }
        np.savez(os.path.join(OUT_DIR, "shap_values_dft.npz"),
                 shap_values=shap_values, X_sbx=X_sbx,
                 feature_names=np.array(sbx_features, dtype=object),
                 elem_b=df_sbx["elem_b"].values,
                 y_sbx=y_sbx, preds_tl=preds_tl,
                 preds_loeo_t=preds_loeo_t)
    except Exception as e:
        print(f"  SHAP失败: {e}")
        results["shap"] = {"error": str(e)}

    # ---- 保存结果 ----
    df_sbx_out = df_sbx.copy()
    df_sbx_out["pred_E_sub_loocv"] = preds_tl
    df_sbx_out["pred_E_sub_loeo"] = preds_loeo_t
    df_sbx_out["residual"] = y_sbx - preds_tl
    df_sbx_out.to_csv(os.path.join(OUT_DIR, "sbox_predictions_dft.csv"),
                      index=False, encoding="utf-8-sig")

    df_pre_out = df_pre.copy()
    df_pre_out["pred_E_form_5fold"] = preds_pre
    df_pre_out.to_csv(os.path.join(OUT_DIR, "pretrain_predictions_dft.csv"),
                      index=False, encoding="utf-8-sig")

    with open(os.path.join(OUT_DIR, "dft_results.json"), "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)

    print("\n" + "=" * 60)
    print("Pipeline完成！")
    print("=" * 60)
    return results, df_pre, df_sbx


if __name__ == "__main__":
    pre_path = os.path.join(DATA, "mp_pretrain_binary.csv")
    sbx_path = os.path.join(DATA, "mp_sbx_binary.csv")
    if not os.path.exists(pre_path) or not os.path.exists(sbx_path):
        print("错误：请先运行 download_mp_data.py")
    else:
        df_pre_raw = pd.read_csv(pre_path)
        df_sbx_raw = pd.read_csv(sbx_path)
        print(f"读取预训练数据: {len(df_pre_raw)} 条")
        print(f"读取Sb-X数据: {len(df_sbx_raw)} 条")
        df_pre = build_pretrain_dataset(df_pre_raw)
        df_sbx = build_sbx_dataset(df_sbx_raw)
        results, df_pre, df_sbx = run_transfer_learning(df_pre, df_sbx)
        # 生成下游脚本（predict_si.py / exp_validation2.py）需要的共享模块
        import shutil
        shutil.copy(os.path.abspath(__file__), os.path.join(OUT, "run_pipeline_dft.py"))
        print("已生成共享模块:", os.path.join(OUT, "run_pipeline_dft.py"))
