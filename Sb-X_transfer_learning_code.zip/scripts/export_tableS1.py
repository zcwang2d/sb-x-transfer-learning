# -*- coding: utf-8 -*-
"""导出完整 Table S1：334条 Sb-X 描述符+DFT+LOOCV/LOEO预测+残差"""
import pandas as pd, numpy as np, os
_HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(_HERE, "..", "results")
OUT_DIR = OUT
DATA = os.path.join(_HERE, "..", "data")
os.makedirs(OUT, exist_ok=True)
df=pd.read_csv(os.path.join(DATA, "fixed_sbox_predictions.csv"))
cols=["material_id","formula","elem_b","c_b",
 "epsilon","dchi","dm","dTm","dI","dK","VEC","dH_mix","dS_mix",
 "E_sub","pred_E_sub_loocv","pred_E_sub_loeo","pred_E_sub_loeo_direct"]
t=df[cols].copy()
t["resid_LOEO"]=t["pred_E_sub_loeo"]-t["E_sub"]
t.columns=["MP-ID","Formula","X","c_X","epsilon","dchi","dm","dTm","dI","dK","VEC",
 "dH_mix(kJ/mol)","dS_mix(J/mol/K)","E_form(eV/atom)","Pred_LOOCV","Pred_LOEO_transfer",
 "Pred_LOEO_direct","Residual_LOEO"]
t=t.sort_values(["X","MP-ID"]).reset_index(drop=True)
path=os.path.join(OUT,"TableS1_full_334_SbX_fixed.csv")
t.to_csv(path,index=False,encoding="utf-8-sig")
print(f"Saved {path}: {len(t)} rows")
print(t.head(3).to_string())
