# -*- coding: utf-8 -*-
"""Continue rerun: VIF, permutation test, bootstrap, element-wise CI"""
import os, json, warnings
import numpy as np
import pandas as pd
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.model_selection import KFold
import xgboost as xgb
from scipy.cluster.hierarchy import linkage, fcluster
from scipy.spatial.distance import squareform
from statsmodels.stats.outliers_influence import variance_inflation_factor

warnings.filterwarnings("ignore")
np.random.seed(42)
SEED = 42
_HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(_HERE, "..", "results")
OUT_DIR = OUT
DATA = os.path.join(_HERE, "..", "data")
os.makedirs(OUT, exist_ok=True)

# ============================================================
# 1. Load data and build features
# ============================================================
print("STEP 1: Load data and build features")

df_pre_raw = pd.read_csv(os.path.join(DATA, "mp_pretrain_binary.csv"))
df_sbx = pd.read_csv(os.path.join(DATA, "mp_sbx_binary.csv"))
sbx_ids = set(df_sbx["material_id"].values)
df_pre_clean = df_pre_raw[~df_pre_raw["material_id"].isin(sbx_ids)].copy()

import importlib.util
spec = importlib.util.spec_from_file_location("pipeline", os.path.join(OUT, "Code_S1_pipeline.py"))
pipe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pipe)

FEATURES = ["epsilon","dchi","dm","dTm","c","dI","dK","VEC",
            "epsilon2","dchi2","dm2","epsilon_c","dchi_c","dm_c",
            "dH_mix","dS_mix"]

df_pre = pipe.build_pretrain_dataset(df_pre_clean)
df_sbx_feat = pipe.build_sbx_dataset(df_sbx)

X_pre = df_pre[FEATURES].values
y_pre = df_pre["E_form"].values
X_sbx = df_sbx_feat[FEATURES].values
y_sbx = df_sbx_feat["E_sub"].values
elem_sbx = df_sbx_feat["elem_b"].values
unique_elems = sorted(set(elem_sbx))

print(f"Pretrain: {X_pre.shape}, Sb-X: {X_sbx.shape}")

# ============================================================
# 2. Pretrain and LOEO
# ============================================================
print("\nSTEP 2: Pretrain and LOEO")

pre_model = pipe.train_xgb(X_pre, y_pre, n_estimators=300, max_depth=6, lr=0.1, seed=SEED)

# LOEO
loeo_preds = np.zeros(len(y_sbx))
loeo_true = np.zeros(len(y_sbx))
loeo_elem = np.array([""] * len(y_sbx), dtype=object)
idx = 0
for e in unique_elems:
    test_mask = elem_sbx == e
    train_mask = ~test_mask
    m = pipe.train_xgb(X_sbx[train_mask], y_sbx[train_mask], n_estimators=200, max_depth=4,
                        lr=0.1, xgb_init=pre_model, seed=SEED)
    preds = m.predict(X_sbx[test_mask])
    n = test_mask.sum()
    loeo_preds[idx:idx+n] = preds
    loeo_true[idx:idx+n] = y_sbx[test_mask]
    loeo_elem[idx:idx+n] = e
    idx += n

loeo = {
    "r2": float(r2_score(loeo_true, loeo_preds)),
    "mae": float(mean_absolute_error(loeo_true, loeo_preds)),
}
print(f"LOEO: R2={loeo['r2']:.3f}, MAE={loeo['mae']:.3f}")

# Direct training LOEO
direct_loeo_preds = np.zeros(len(y_sbx))
idx = 0
for e in unique_elems:
    test_mask = elem_sbx == e
    train_mask = ~test_mask
    m = pipe.train_xgb(X_sbx[train_mask], y_sbx[train_mask], n_estimators=200, max_depth=4,
                        lr=0.1, seed=SEED)
    preds = m.predict(X_sbx[test_mask])
    n = test_mask.sum()
    direct_loeo_preds[idx:idx+n] = preds
    idx += n

direct_train_loeo = {
    "r2": float(r2_score(loeo_true, direct_loeo_preds)),
    "mae": float(mean_absolute_error(loeo_true, direct_loeo_preds)),
}
print(f"Direct LOEO: R2={direct_train_loeo['r2']:.3f}")

# ============================================================
# 3. VIF and multicollinearity
# ============================================================
print("\nSTEP 3: VIF analysis")

vif_data = []
X_vif = pd.DataFrame(X_sbx, columns=FEATURES)
for i, col in enumerate(FEATURES):
    try:
        vif = variance_inflation_factor(X_vif.values, i)
    except:
        vif = float("inf")
    vif_data.append({"feature": col, "VIF": float(vif)})

print("High VIF features:")
for v in vif_data:
    if v["VIF"] > 10:
        print(f"  {v['feature']}: {v['VIF']:.1f}")

# Hierarchical clustering
corr_matrix = np.abs(np.corrcoef(X_sbx.T))
np.fill_diagonal(corr_matrix, 0)
dist_matrix = 1 - corr_matrix
dist_matrix = (dist_matrix + dist_matrix.T) / 2  # force symmetry
np.fill_diagonal(dist_matrix, 0)
linkage_matrix = linkage(squareform(dist_matrix), method="average")
clusters = fcluster(linkage_matrix, t=8, criterion="maxclust")

feature_clusters = {}
for i, c in enumerate(clusters):
    feature_clusters.setdefault(str(c), []).append(FEATURES[i])

selected_features = []
for c, feats in feature_clusters.items():
    best = min(feats, key=lambda f: next(v["VIF"] for v in vif_data if v["feature"] == f))
    selected_features.append(best)
print(f"Selected {len(selected_features)} dedup features: {selected_features}")

# Dedup model LOEO
X_dedup = X_sbx[:, [FEATURES.index(f) for f in selected_features]]
dedup_loeo_preds = np.zeros(len(y_sbx))
idx = 0
for e in unique_elems:
    test_mask = elem_sbx == e
    train_mask = ~test_mask
    m = xgb.XGBRegressor(n_estimators=200, max_depth=4, learning_rate=0.1,
                          random_state=SEED, verbosity=0)
    m.fit(X_dedup[train_mask], y_sbx[train_mask])
    preds = m.predict(X_dedup[test_mask])
    n = test_mask.sum()
    dedup_loeo_preds[idx:idx+n] = preds
    idx += n

dedup_transfer = {
    "r2": float(r2_score(loeo_true, dedup_loeo_preds)),
    "mae": float(mean_absolute_error(loeo_true, dedup_loeo_preds)),
    "selected_features": selected_features,
}
print(f"Dedup LOEO: R2={dedup_transfer['r2']:.3f}")

# Single-feature fits
single_feature = {}
for feat in ["dH_mix", "dchi", "epsilon", "dTm"]:
    idx_f = FEATURES.index(feat)
    x_f = X_sbx[:, idx_f]
    r = np.corrcoef(x_f, y_sbx)[0, 1]
    single_feature[feat] = {"r": float(r), "r2": float(r**2)}
    print(f"  {feat}: r={r:.3f}")

# ============================================================
# 4. Permutation test (200)
# ============================================================
print("\nSTEP 4: Permutation test (200)")

rng = np.random.RandomState(SEED)
n_perm = 200
perm_r2 = []
for i in range(n_perm):
    y_perm = rng.permutation(y_sbx)
    perm_loeo_preds = np.zeros(len(y_sbx))
    idx = 0
    for e in unique_elems:
        test_mask = elem_sbx == e
        train_mask = ~test_mask
        m = pipe.train_xgb(X_sbx[train_mask], y_perm[train_mask], n_estimators=200, max_depth=4,
                            lr=0.1, xgb_init=pre_model, seed=SEED)
        preds = m.predict(X_sbx[test_mask])
        n = test_mask.sum()
        perm_loeo_preds[idx:idx+n] = preds
        idx += n
    r2_perm = r2_score(loeo_true, perm_loeo_preds)
    perm_r2.append(r2_perm)
    if (i+1) % 50 == 0:
        print(f"  Permutation {i+1}/{n_perm}: mean R2={np.mean(perm_r2):.3f}")

p_value = sum(1 for r in perm_r2 if r >= loeo["r2"]) / n_perm
permutation_test = {
    "n_permutations": n_perm,
    "perm_r2_mean": float(np.mean(perm_r2)),
    "perm_r2_std": float(np.std(perm_r2)),
    "true_r2": float(loeo["r2"]),
    "p_value": float(p_value),
    "perm_r2_values": perm_r2,
}
print(f"Permutation p={p_value:.4f}")

# ============================================================
# 5. Bootstrap significance test (1000)
# ============================================================
print("\nSTEP 5: Bootstrap significance (1000)")

n_boot = 1000
residuals_transfer = loeo_true - loeo_preds
residuals_direct = loeo_true - direct_loeo_preds

boot_r2_diff = []
boot_mae_diff = []

for i in range(n_boot):
    pred_boot = np.zeros(len(loeo_true))
    pred_direct_boot = np.zeros(len(loeo_true))
    idx = 0
    for e in unique_elems:
        mask = loeo_elem[:len(loeo_true)] == e
        n_e = mask.sum()
        if n_e == 0:
            continue
        resample_idx = rng.choice(n_e, size=n_e, replace=True)
        pred_boot[idx:idx+n_e] = loeo_true[idx:idx+n_e] - residuals_transfer[idx:idx+n_e][resample_idx]
        pred_direct_boot[idx:idx+n_e] = loeo_true[idx:idx+n_e] - residuals_direct[idx:idx+n_e][resample_idx]
        idx += n_e
    
    r2_t = r2_score(loeo_true, pred_boot)
    r2_d = r2_score(loeo_true, pred_direct_boot)
    mae_t = mean_absolute_error(loeo_true, pred_boot)
    mae_d = mean_absolute_error(loeo_true, pred_direct_boot)
    boot_r2_diff.append(r2_t - r2_d)
    boot_mae_diff.append(mae_t - mae_d)

boot_r2_diff = np.array(boot_r2_diff)
boot_mae_diff = np.array(boot_mae_diff)

bootstrap_significance = {
    "r2_diff_mean": float(np.mean(boot_r2_diff)),
    "r2_diff_std": float(np.std(boot_r2_diff)),
    "r2_ci": [float(np.percentile(boot_r2_diff, 2.5)), float(np.percentile(boot_r2_diff, 97.5))],
    "r2_p": float(np.mean(boot_r2_diff <= 0)),
    "mae_diff_mean": float(np.mean(boot_mae_diff)),
    "mae_ci": [float(np.percentile(boot_mae_diff, 2.5)), float(np.percentile(boot_mae_diff, 97.5))],
    "mae_p": float(np.mean(boot_mae_diff >= 0)),
}
print(f"R2 diff: {bootstrap_significance['r2_diff_mean']:.3f} +/- {bootstrap_significance['r2_diff_std']:.3f}")
print(f"R2 CI: [{bootstrap_significance['r2_ci'][0]:.3f}, {bootstrap_significance['r2_ci'][1]:.3f}]")
print(f"R2 p={bootstrap_significance['r2_p']:.4f}")

# ============================================================
# 6. Element-wise bootstrap CI
# ============================================================
print("\nSTEP 6: Element-wise bootstrap CI")

elem_bootstrap_ci = {}
for e in unique_elems:
    mask = loeo_elem[:len(loeo_true)] == e
    n_e = mask.sum()
    if n_e < 2:
        continue
    res_e = residuals_transfer[mask]
    mae_boot = []
    for _ in range(500):
        resample = rng.choice(n_e, size=n_e, replace=True)
        mae_boot.append(np.mean(np.abs(res_e[resample])))
    elem_bootstrap_ci[e] = {
        "n": int(n_e),
        "mae_mean": float(np.mean(np.abs(res_e))),
        "mae_ci": [float(np.percentile(mae_boot, 2.5)), float(np.percentile(mae_boot, 97.5))],
    }

print(f"Element-wise CI for {len(elem_bootstrap_ci)} elements")

# ============================================================
# 7. Save results
# ============================================================
print("\nSTEP 7: Save results")

results = {
    "data_leakage_fixed": True,
    "pretrain_size_clean": int(len(X_pre)),
    "sbx_size": int(len(X_sbx)),
    "loeo": loeo,
    "direct_train_loeo": direct_train_loeo,
    "vif": vif_data,
    "feature_clusters": feature_clusters,
    "selected_features": selected_features,
    "dedup_transfer": dedup_transfer,
    "single_feature": single_feature,
    "permutation_test": permutation_test,
    "bootstrap_significance": bootstrap_significance,
    "elem_bootstrap_ci": elem_bootstrap_ci,
    "seed": SEED,
}

with open(os.path.join(OUT, "results_fixed_remaining.json"), "w", encoding="utf-8") as f:
    json.dump(results, f, indent=2, ensure_ascii=False)

print("Saved to results_fixed_remaining.json")
print("\n" + "=" * 60)
print("FINAL SUMMARY")
print("=" * 60)
print(f"LOEO R2: {loeo['r2']:.3f} (was 0.888 with leakage)")
print(f"LOEO MAE: {loeo['mae']:.3f} (was 0.139 with leakage)")
print(f"Direct R2: {direct_train_loeo['r2']:.3f}")
print(f"Transfer gain: {loeo['r2'] - direct_train_loeo['r2']:.3f}")
print(f"Dedup R2: {dedup_transfer['r2']:.3f}")
print(f"Permutation p: {permutation_test['p_value']:.4f}")
print(f"Bootstrap R2 p: {bootstrap_significance['r2_p']:.4f}")
