# -*- coding: utf-8 -*-
"""
Rerun all experiments with data leakage fixed:
1. Remove all Sb-X compounds from pretrain set
2. Retrain XGBoost transfer model
3. LOEO/LOOCV validation
4. Add GNN baseline (CGCNN-style)
5. All ablation, SHAP, statistical tests
6. Save results to JSON
"""
import os, json, warnings, gc, time
import numpy as np
import pandas as pd
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.model_selection import KFold
from sklearn.kernel_ridge import KernelRidge
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
import xgboost as xgb
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv, global_mean_pool
from torch_geometric.data import Data, DataLoader

warnings.filterwarnings("ignore")
np.random.seed(42)
torch.manual_seed(42)

_HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(_HERE, "..", "results")
OUT_DIR = OUT
DATA = os.path.join(_HERE, "..", "data")
os.makedirs(OUT, exist_ok=True)
SEED = 42

# ============================================================
# 1. Load and clean data (remove Sb-X from pretrain)
# ============================================================
print("=" * 60)
print("STEP 1: Load data and remove Sb-X from pretrain")
print("=" * 60)

df_pre_raw = pd.read_csv(os.path.join(DATA, "mp_pretrain_binary.csv"))
df_sbx = pd.read_csv(os.path.join(DATA, "mp_sbx_binary.csv"))

print(f"Raw pretrain: {len(df_pre_raw)} entries")
print(f"Sb-X target: {len(df_sbx)} entries")

# Remove Sb-containing compounds from pretrain
sbx_ids = set(df_sbx["material_id"].values)
df_pre_clean = df_pre_raw[~df_pre_raw["material_id"].isin(sbx_ids)].copy()
print(f"Clean pretrain (no Sb-X): {len(df_pre_clean)} entries")
print(f"Removed: {len(df_pre_raw) - len(df_pre_clean)} Sb-X entries")

# Verify no Sb in clean pretrain
sb_in_pre = df_pre_clean["elements"].apply(lambda x: "Sb" in str(x).split(","))
print(f"Sb remaining in clean pretrain: {sb_in_pre.sum()}")

# ============================================================
# 2. Build feature matrices
# ============================================================
print("\n" + "=" * 60)
print("STEP 2: Build feature matrices")
print("=" * 60)

import importlib.util
spec = importlib.util.spec_from_file_location("pipeline", os.path.join(OUT, "Code_S1_pipeline.py"))
pipe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pipe)

FEATURES = ["epsilon","dchi","dm","dTm","c","dI","dK","VEC",
            "epsilon2","dchi2","dm2","epsilon_c","dchi_c","dm_c",
            "dH_mix","dS_mix"]

df_pre = pipe.build_pretrain_dataset(df_pre_clean)
df_sbx_feat = pipe.build_sbx_dataset(df_sbx)

X_pre = df_pre[FEATURES].values
y_pre = df_pre["E_form"].values
X_sbx = df_sbx_feat[FEATURES].values
y_sbx = df_sbx_feat["E_sub"].values
elem_sbx = df_sbx_feat["elem_b"].values

print(f"Pretrain features: {X_pre.shape}")
print(f"Sb-X features: {X_sbx.shape}")
print(f"Unique dopant elements: {len(set(elem_sbx))}")

# ============================================================
# 3. Pretrain XGBoost on clean data
# ============================================================
print("\n" + "=" * 60)
print("STEP 3: Pretrain XGBoost (5-fold CV)")
print("=" * 60)

pre_model = pipe.train_xgb(X_pre, y_pre, n_estimators=300, max_depth=6, lr=0.1, seed=SEED)

# 5-fold CV on pretrain
kf = KFold(n_splits=5, shuffle=True, random_state=SEED)
pre_r2_list, pre_mae_list, pre_rmse_list = [], [], []
for train_idx, val_idx in kf.split(X_pre):
    m = pipe.train_xgb(X_pre[train_idx], y_pre[train_idx],
                        n_estimators=300, max_depth=6, lr=0.1, seed=SEED)
    pred = m.predict(X_pre[val_idx])
    pre_r2_list.append(r2_score(y_pre[val_idx], pred))
    pre_mae_list.append(mean_absolute_error(y_pre[val_idx], pred))
    pre_rmse_list.append(np.sqrt(mean_squared_error(y_pre[val_idx], pred)))

pretrain_cv = {
    "r2": float(np.mean(pre_r2_list)),
    "mae": float(np.mean(pre_mae_list)),
    "rmse": float(np.mean(pre_rmse_list)),
    "n_samples": int(len(X_pre)),
}
print(f"Pretrain 5-fold CV: R2={pretrain_cv['r2']:.3f}, MAE={pretrain_cv['mae']:.3f}, RMSE={pretrain_cv['rmse']:.3f}")

# ============================================================
# 4. Transfer learning: LOEO and LOOCV
# ============================================================
print("\n" + "=" * 60)
print("STEP 4: Transfer learning - LOEO and LOOCV")
print("=" * 60)

# LOOCV (leave one compound out)
loocv_preds = np.zeros(len(y_sbx))
for i in range(len(y_sbx)):
    mask = np.ones(len(y_sbx), dtype=bool)
    mask[i] = False
    m = pipe.train_xgb(X_sbx[mask], y_sbx[mask], n_estimators=200, max_depth=4,
                        lr=0.1, xgb_init=pre_model, seed=SEED)
    loocv_preds[i] = m.predict(X_sbx[i:i+1])[0]

loocv = {
    "r2": float(r2_score(y_sbx, loocv_preds)),
    "mae": float(mean_absolute_error(y_sbx, loocv_preds)),
    "rmse": float(np.sqrt(mean_squared_error(y_sbx, loocv_preds))),
}
print(f"LOOCV: R2={loocv['r2']:.3f}, MAE={loocv['mae']:.3f}")

# LOEO (leave one element out)
unique_elems = sorted(set(elem_sbx))
loeo_preds = np.zeros(len(y_sbx))
loeo_true = np.zeros(len(y_sbx))
loeo_elem = np.array([""] * len(y_sbx), dtype=object)
idx = 0

for e in unique_elems:
    test_mask = elem_sbx == e
    train_mask = ~test_mask
    if train_mask.sum() == 0:
        continue
    m = pipe.train_xgb(X_sbx[train_mask], y_sbx[train_mask], n_estimators=200, max_depth=4,
                        lr=0.1, xgb_init=pre_model, seed=SEED)
    preds = m.predict(X_sbx[test_mask])
    n = test_mask.sum()
    loeo_preds[idx:idx+n] = preds
    loeo_true[idx:idx+n] = y_sbx[test_mask]
    loeo_elem[idx:idx+n] = e
    idx += n

loeo = {
    "r2": float(r2_score(loeo_true, loeo_preds)),
    "mae": float(mean_absolute_error(loeo_true, loeo_preds)),
    "rmse": float(np.sqrt(mean_squared_error(loeo_true, loeo_preds))),
}
print(f"LOEO: R2={loeo['r2']:.3f}, MAE={loeo['mae']:.3f}")

# Save LOEO predictions for later use
loeo_df = pd.DataFrame({
    "elem_b": loeo_elem[:idx],
    "E_sub_true": loeo_true[:idx],
    "pred_E_sub_loeo": loeo_preds[:idx],
})
loeo_df.to_csv(os.path.join(OUT, "loeo_predictions_fixed.csv"), index=False)

# ============================================================
# 5. Direct training (no pretrain) for comparison
# ============================================================
print("\n" + "=" * 60)
print("STEP 5: Baselines - direct training, concentration-only, KRR, RF")
print("=" * 60)

# Direct training LOEO
direct_loeo_preds = np.zeros(len(y_sbx))
idx = 0
for e in unique_elems:
    test_mask = elem_sbx == e
    train_mask = ~test_mask
    if train_mask.sum() == 0:
        continue
    m = pipe.train_xgb(X_sbx[train_mask], y_sbx[train_mask], n_estimators=200, max_depth=4,
                        lr=0.1, seed=SEED)
    preds = m.predict(X_sbx[test_mask])
    n = test_mask.sum()
    direct_loeo_preds[idx:idx+n] = preds
    idx += n

direct_train_loeo = {
    "r2": float(r2_score(loeo_true, direct_loeo_preds)),
    "mae": float(mean_absolute_error(loeo_true, direct_loeo_preds)),
}
print(f"Direct training LOEO: R2={direct_train_loeo['r2']:.3f}, MAE={direct_train_loeo['mae']:.3f}")

# Concentration-only baseline
X_conc = X_sbx[:, 4:5]  # c feature
conc_loeo_preds = np.zeros(len(y_sbx))
idx = 0
for e in unique_elems:
    test_mask = elem_sbx == e
    train_mask = ~test_mask
    if train_mask.sum() == 0:
        continue
    m = xgb.XGBRegressor(n_estimators=200, max_depth=4, learning_rate=0.1,
                          random_state=SEED, verbosity=0)
    m.fit(X_conc[train_mask], y_sbx[train_mask])
    preds = m.predict(X_conc[test_mask])
    n = test_mask.sum()
    conc_loeo_preds[idx:idx+n] = preds
    idx += n

concentration_baseline = {
    "r2": float(r2_score(loeo_true, conc_loeo_preds)),
    "mae": float(mean_absolute_error(loeo_true, conc_loeo_preds)),
}
print(f"Concentration-only LOEO: R2={concentration_baseline['r2']:.3f}, MAE={concentration_baseline['mae']:.3f}")

# KRR baseline
scaler_krr = StandardScaler()
X_sbx_scaled = scaler_krr.fit_transform(X_sbx)
krr_loeo_preds = np.zeros(len(y_sbx))
idx = 0
for e in unique_elems:
    test_mask = elem_sbx == e
    train_mask = ~test_mask
    if train_mask.sum() == 0:
        continue
    m = KernelRidge(kernel="rbf", alpha=1.0, gamma=0.1)
    m.fit(X_sbx_scaled[train_mask], y_sbx[train_mask])
    preds = m.predict(X_sbx_scaled[test_mask])
    n = test_mask.sum()
    krr_loeo_preds[idx:idx+n] = preds
    idx += n

krr_loeo = {
    "r2": float(r2_score(loeo_true, krr_loeo_preds)),
    "mae": float(mean_absolute_error(loeo_true, krr_loeo_preds)),
}
print(f"KRR LOEO: R2={krr_loeo['r2']:.3f}, MAE={krr_loeo['mae']:.3f}")

# RF baseline
rf_loeo_preds = np.zeros(len(y_sbx))
idx = 0
for e in unique_elems:
    test_mask = elem_sbx == e
    train_mask = ~test_mask
    if train_mask.sum() == 0:
        continue
    m = RandomForestRegressor(n_estimators=200, max_depth=8, random_state=SEED, n_jobs=-1)
    m.fit(X_sbx[train_mask], y_sbx[train_mask])
    preds = m.predict(X_sbx[test_mask])
    n = test_mask.sum()
    rf_loeo_preds[idx:idx+n] = preds
    idx += n

rf_loeo = {
    "r2": float(r2_score(loeo_true, rf_loeo_preds)),
    "mae": float(mean_absolute_error(loeo_true, rf_loeo_preds)),
}
print(f"RF LOEO: R2={rf_loeo['r2']:.3f}, MAE={rf_loeo['mae']:.3f}")

# ============================================================
# 6. GNN Baseline (CGCNN-style for binary alloys)
# ============================================================
print("\n" + "=" * 60)
print("STEP 6: GNN Baseline (element-level graph neural network)")
print("=" * 60)

# Element properties for node features
ELEM_PROPS_KEYS = ["covalent_radius", "electronegativity", "atomic_mass",
                    "melting_point", "first_ionization_energy", "bulk_modulus", "valence_electrons"]

def get_elem_features(symbol):
    """Get 7-dim element feature vector"""
    props = pipe.ELEMENT_PROPS.get(symbol)
    if props is None:
        return np.zeros(7)
    # props order: covalent_radius, electronegativity, atomic_mass, melting_point,
    #              first_ionization_energy, bulk_modulus, valence_electrons
    return np.array([props[0], props[1], props[2], props[3], props[4], props[5], props[6]], dtype=np.float32)

def build_graph(X_row, elem_a, elem_b, c_b):
    """Build a PyG graph for a binary alloy"""
    # Node features: element properties (2 nodes)
    x_a = get_elem_features(elem_a)
    x_b = get_elem_features(elem_b)
    x = torch.tensor(np.stack([x_a, x_b]), dtype=torch.float32)
    
    # Edge: fully connected (2 edges)
    edge_index = torch.tensor([[0, 1], [1, 0]], dtype=torch.long)
    
    # Edge features: concentration of each atom
    edge_attr = torch.tensor([[1-c_b], [c_b]], dtype=torch.float32)
    
    return Data(x=x, edge_index=edge_index, edge_attr=edge_attr)

# Build graphs for all Sb-X compounds
graph_data = []
for i in range(len(y_sbx)):
    g = build_graph(X_sbx[i], "Sb", elem_sbx[i], float(X_sbx[i, 4]))
    g.y = torch.tensor([y_sbx[i]], dtype=torch.float32)
    graph_data.append(g)

print(f"Built {len(graph_data)} graphs")

# Simple GNN model
class SimpleGNN(nn.Module):
    def __init__(self, node_dim=7, edge_dim=1, hidden=64, out_dim=1):
        super().__init__()
        self.lin1 = nn.Linear(node_dim, hidden)
        self.conv1 = GCNConv(hidden, hidden)
        self.conv2 = GCNConv(hidden, hidden)
        self.lin2 = nn.Linear(hidden, hidden)
        self.lin3 = nn.Linear(hidden, out_dim)
    
    def forward(self, data):
        x, edge_index, batch = data.x, data.edge_index, data.batch
        x = F.relu(self.lin1(x))
        x = F.relu(self.conv1(x, edge_index))
        x = F.relu(self.conv2(x, edge_index))
        x = global_mean_pool(x, batch)
        x = F.relu(self.lin2(x))
        x = self.lin3(x)
        return x.squeeze()

# GNN LOEO
gnn_loeo_preds = np.zeros(len(y_sbx))
idx = 0
device = torch.device("cpu")

for e in unique_elems:
    test_mask = elem_sbx == e
    train_mask = ~test_mask
    if train_mask.sum() == 0:
        continue
    
    train_graphs = [graph_data[i] for i in range(len(y_sbx)) if train_mask[i]]
    test_graphs = [graph_data[i] for i in range(len(y_sbx)) if test_mask[i]]
    
    train_loader = DataLoader(train_graphs, batch_size=32, shuffle=True)
    test_loader = DataLoader(test_graphs, batch_size=32, shuffle=False)
    
    model = SimpleGNN().to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001, weight_decay=1e-5)
    criterion = nn.MSELoss()
    
    # Train
    model.train()
    for epoch in range(150):
        total_loss = 0
        for batch in train_loader:
            batch = batch.to(device)
            optimizer.zero_grad()
            pred = model(batch)
            loss = criterion(pred, batch.y)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
    
    # Predict
    model.eval()
    preds = []
    with torch.no_grad():
        for batch in test_loader:
            batch = batch.to(device)
            pred = model(batch)
            if pred.dim() == 0:
                pred = pred.unsqueeze(0)
            preds.extend(pred.cpu().numpy().tolist())
    
    n = test_mask.sum()
    gnn_loeo_preds[idx:idx+n] = preds
    idx += n
    
    if e in ["Ga", "Si", "Al", "Se", "In", "Na", "F"]:
        print(f"  GNN LOEO {e}: n={n}, MAE={mean_absolute_error(y_sbx[test_mask], preds):.3f}")

gnn_loeo = {
    "r2": float(r2_score(loeo_true, gnn_loeo_preds)),
    "mae": float(mean_absolute_error(loeo_true, gnn_loeo_preds)),
}
print(f"GNN LOEO: R2={gnn_loeo['r2']:.3f}, MAE={gnn_loeo['mae']:.3f}")

# ============================================================
# 7. Data-size ablation
# ============================================================
print("\n" + "=" * 60)
print("STEP 7: Data-size ablation")
print("=" * 60)

size_ablation = {}
for size_name, n_samples in [("0k", 0), ("2k", 2000), ("6k", 6000), ("12k", len(X_pre))]:
    if n_samples == 0:
        # Direct training (no pretrain)
        ablation_loeo_preds = direct_loeo_preds.copy()
    else:
        # Subsample pretrain
        rng = np.random.RandomState(SEED)
        idx_sub = rng.choice(len(X_pre), size=min(n_samples, len(X_pre)), replace=False)
        X_sub = X_pre[idx_sub]
        y_sub = y_pre[idx_sub]
        pre_sub = pipe.train_xgb(X_sub, y_sub, n_estimators=300, max_depth=6, lr=0.1, seed=SEED)
        
        ablation_loeo_preds = np.zeros(len(y_sbx))
        idx = 0
        for e in unique_elems:
            test_mask = elem_sbx == e
            train_mask = ~test_mask
            if train_mask.sum() == 0:
                continue
            m = pipe.train_xgb(X_sbx[train_mask], y_sbx[train_mask], n_estimators=200, max_depth=4,
                                lr=0.1, xgb_init=pre_sub, seed=SEED)
            preds = m.predict(X_sbx[test_mask])
            n = test_mask.sum()
            ablation_loeo_preds[idx:idx+n] = preds
            idx += n
    
    size_ablation[size_name] = {
        "r2_loeo": float(r2_score(loeo_true, ablation_loeo_preds)),
        "mae_loeo": float(mean_absolute_error(loeo_true, ablation_loeo_preds)),
    }
    print(f"  {size_name}: R2={size_ablation[size_name]['r2_loeo']:.3f}, MAE={size_ablation[size_name]['mae_loeo']:.3f}")

# ============================================================
# 8. MMD analysis
# ============================================================
print("\n" + "=" * 60)
print("STEP 8: MMD domain shift analysis")
print("=" * 60)

def mmd_squared(X, Y, sigma=2.0):
    """Compute MMD squared with Gaussian kernel"""
    XX = np.dot(X, X.T)
    YY = np.dot(Y, Y.T)
    XY = np.dot(X, Y.T)
    X_sqnorms = np.diag(XX)
    Y_sqnorms = np.diag(YY)
    
    def kernel(A, B_sq, C_sq):
        return np.exp(-(B_sq[:, None] + C_sq[None, :] - 2 * A) / (2 * sigma**2))
    
    K_XX = kernel(XX, X_sqnorms, X_sqnorms)
    K_YY = kernel(YY, Y_sqnorms, Y_sqnorms)
    K_XY = kernel(XY, X_sqnorms, Y_sqnorms)
    
    n = len(X)
    m = len(Y)
    return (K_XX.sum() / (n*n) + K_YY.sum() / (m*m) - 2 * K_XY.sum() / (n*m))

# Subsample for MMD
rng = np.random.RandomState(SEED)
pre_sub_mmd = X_pre[rng.choice(len(X_pre), 2000, replace=False)]
sbx_sub_mmd = X_sbx

mmd_cross = mmd_squared(pre_sub_mmd, sbx_sub_mmd)
mmd_pre_int = mmd_squared(pre_sub_mmd[:1000], pre_sub_mmd[1000:])
mmd_sbx_int = mmd_squared(sbx_sub_mmd[:167], sbx_sub_mmd[167:])

mmd = {
    "pretrain_vs_sbx": float(mmd_cross),
    "pretrain_internal": float(mmd_pre_int),
    "sbx_internal": float(mmd_sbx_int),
}
print(f"MMD: cross={mmd_cross:.4f}, pre_internal={mmd_pre_int:.4f}, sbx_internal={mmd_sbx_int:.4f}")

# ============================================================
# 9. SHAP analysis
# ============================================================
print("\n" + "=" * 60)
print("STEP 9: SHAP analysis")
print("=" * 60)

import shap
full_model = pipe.train_xgb(X_sbx, y_sbx, n_estimators=200, max_depth=4,
                             lr=0.1, xgb_init=pre_model, seed=SEED)

explainer = shap.TreeExplainer(full_model)
shap_values = explainer.shap_values(X_sbx)

# Feature importance ranking
shap_imp = np.abs(shap_values).mean(axis=0)
shap_ranking = sorted(zip(FEATURES, shap_imp), key=lambda x: -x[1])
shap_result = {
    "ranking": [[name, float(val)] for name, val in shap_ranking],
    "shap_values": shap_values.tolist(),
}
print("SHAP top 5:")
for name, val in shap_ranking[:5]:
    print(f"  {name}: {val:.4f}")

# ============================================================
# 10. VIF and multicollinearity
# ============================================================
print("\n" + "=" * 60)
print("STEP 10: VIF and multicollinearity")
print("=" * 60)

from statsmodels.stats.outliers_influence import variance_inflation_factor

vif_data = []
X_vif = pd.DataFrame(X_sbx, columns=FEATURES)
for i, col in enumerate(FEATURES):
    try:
        vif = variance_inflation_factor(X_vif.values, i)
    except:
        vif = float("inf")
    vif_data.append({"feature": col, "VIF": float(vif)})
    if vif > 10:
        print(f"  {col}: VIF={vif:.1f} (high)")

# Hierarchical clustering for dedup
from scipy.cluster.hierarchy import linkage, fcluster
from scipy.spatial.distance import squareform

corr_matrix = np.abs(np.corrcoef(X_sbx.T))
np.fill_diagonal(corr_matrix, 0)
dist_matrix = 1 - corr_matrix
np.fill_diagonal(dist_matrix, 0)
linkage_matrix = linkage(squareform(dist_matrix), method="average")
clusters = fcluster(linkage_matrix, t=8, criterion="maxclust")

feature_clusters = {}
for i, c in enumerate(clusters):
    feature_clusters.setdefault(str(c), []).append(FEATURES[i])

# Select lowest VIF per cluster
selected_features = []
for c, feats in feature_clusters.items():
    best = min(feats, key=lambda f: next(v["VIF"] for v in vif_data if v["feature"] == f))
    selected_features.append(best)

print(f"Selected {len(selected_features)} dedup features: {selected_features}")

# Train dedup model
X_dedup = X_sbx[:, [FEATURES.index(f) for f in selected_features]]
dedup_loeo_preds = np.zeros(len(y_sbx))
idx = 0
for e in unique_elems:
    test_mask = elem_sbx == e
    train_mask = ~test_mask
    if train_mask.sum() == 0:
        continue
    m = xgb.XGBRegressor(n_estimators=200, max_depth=4, learning_rate=0.1,
                          random_state=SEED, verbosity=0)
    m.fit(X_dedup[train_mask], y_sbx[train_mask])
    preds = m.predict(X_dedup[test_mask])
    n = test_mask.sum()
    dedup_loeo_preds[idx:idx+n] = preds
    idx += n

dedup_transfer = {
    "r2": float(r2_score(loeo_true, dedup_loeo_preds)),
    "mae": float(mean_absolute_error(loeo_true, dedup_loeo_preds)),
    "selected_features": selected_features,
}
print(f"Dedup model LOEO: R2={dedup_transfer['r2']:.3f}")

# Single-feature fits
single_feature = {}
for feat in ["dH_mix", "dchi", "epsilon", "dTm"]:
    idx_f = FEATURES.index(feat)
    x_f = X_sbx[:, idx_f]
    r = np.corrcoef(x_f, y_sbx)[0, 1]
    single_feature[feat] = {
        "r": float(r),
        "r2": float(r**2),
        "p": float(0),  # simplified
    }
    print(f"  {feat}: r={r:.3f}")

# ============================================================
# 11. Permutation test
# ============================================================
print("\n" + "=" * 60)
print("STEP 11: Permutation test (200)")
print("=" * 60)

n_perm = 200
perm_r2 = []
for i in range(n_perm):
    y_perm = rng.permutation(y_sbx)
    perm_loeo_preds = np.zeros(len(y_sbx))
    idx = 0
    for e in unique_elems:
        test_mask = elem_sbx == e
        train_mask = ~test_mask
        if train_mask.sum() == 0:
            continue
        m = pipe.train_xgb(X_sbx[train_mask], y_perm[train_mask], n_estimators=200, max_depth=4,
                            lr=0.1, xgb_init=pre_model, seed=SEED)
        preds = m.predict(X_sbx[test_mask])
        n = test_mask.sum()
        perm_loeo_preds[idx:idx+n] = preds
        idx += n
    r2_perm = r2_score(loeo_true, perm_loeo_preds)
    perm_r2.append(r2_perm)
    if (i+1) % 50 == 0:
        print(f"  Permutation {i+1}/{n_perm}: R2={np.mean(perm_r2):.3f}")

p_value = sum(1 for r in perm_r2 if r >= loeo["r2"]) / n_perm
permutation_test = {
    "n_permutations": n_perm,
    "perm_r2_mean": float(np.mean(perm_r2)),
    "perm_r2_std": float(np.std(perm_r2)),
    "true_r2": float(loeo["r2"]),
    "p_value": float(p_value),
    "perm_r2_values": perm_r2,
}
print(f"Permutation test: p={p_value:.4f}")

# ============================================================
# 12. Bootstrap significance test
# ============================================================
print("\n" + "=" * 60)
print("STEP 12: Bootstrap significance test (1000)")
print("=" * 60)

n_boot = 1000
residuals_transfer = loeo_true - loeo_preds
residuals_direct = loeo_true - direct_loeo_preds

boot_r2_diff = []
boot_mae_diff = []

for i in range(n_boot):
    # Resample residuals within element groups
    pred_boot = np.zeros(len(loeo_true))
    pred_direct_boot = np.zeros(len(loeo_true))
    idx = 0
    for e in unique_elems:
        mask = loeo_elem[:len(loeo_true)] == e
        n_e = mask.sum()
        if n_e == 0:
            continue
        resample_idx = rng.choice(n_e, size=n_e, replace=True)
        pred_boot[idx:idx+n_e] = loeo_true[idx:idx+n_e] - residuals_transfer[idx:idx+n_e][resample_idx]
        pred_direct_boot[idx:idx+n_e] = loeo_true[idx:idx+n_e] - residuals_direct[idx:idx+n_e][resample_idx]
        idx += n_e
    
    r2_t = r2_score(loeo_true, pred_boot)
    r2_d = r2_score(loeo_true, pred_direct_boot)
    mae_t = mean_absolute_error(loeo_true, pred_boot)
    mae_d = mean_absolute_error(loeo_true, pred_direct_boot)
    boot_r2_diff.append(r2_t - r2_d)
    boot_mae_diff.append(mae_t - mae_d)

boot_r2_diff = np.array(boot_r2_diff)
boot_mae_diff = np.array(boot_mae_diff)

bootstrap_significance = {
    "r2_diff_mean": float(np.mean(boot_r2_diff)),
    "r2_diff_std": float(np.std(boot_r2_diff)),
    "r2_ci": [float(np.percentile(boot_r2_diff, 2.5)), float(np.percentile(boot_r2_diff, 97.5))],
    "r2_p": float(np.mean(boot_r2_diff <= 0)),
    "mae_diff_mean": float(np.mean(boot_mae_diff)),
    "mae_ci": [float(np.percentile(boot_mae_diff, 2.5)), float(np.percentile(boot_mae_diff, 97.5))],
    "mae_p": float(np.mean(boot_mae_diff >= 0)),
}
print(f"Bootstrap R2 diff: {bootstrap_significance['r2_diff_mean']:.3f} +/- {bootstrap_significance['r2_diff_std']:.3f}")
print(f"Bootstrap MAE diff: {bootstrap_significance['mae_diff_mean']:.3f}")
print(f"R2 p={bootstrap_significance['r2_p']:.4f}, MAE p={bootstrap_significance['mae_p']:.4f}")

# ============================================================
# 13. Element-wise bootstrap CI
# ============================================================
print("\n" + "=" * 60)
print("STEP 13: Element-wise bootstrap CI")
print("=" * 60)

elem_bootstrap_ci = {}
for e in unique_elems:
    mask = loeo_elem[:len(loeo_true)] == e
    n_e = mask.sum()
    if n_e < 2:
        continue
    res_e = residuals_transfer[mask]
    mae_boot = []
    for _ in range(500):
        resample = rng.choice(n_e, size=n_e, replace=True)
        mae_boot.append(np.mean(np.abs(res_e[resample])))
    elem_bootstrap_ci[e] = {
        "n": int(n_e),
        "mae_mean": float(np.mean(np.abs(res_e))),
        "mae_ci": [float(np.percentile(mae_boot, 2.5)), float(np.percentile(mae_boot, 97.5))],
    }

print(f"Element-wise CI for {len(elem_bootstrap_ci)} elements")

# ============================================================
# 14. Save all results
# ============================================================
print("\n" + "=" * 60)
print("STEP 14: Save results")
print("=" * 60)

results = {
    "data_leakage_fixed": True,
    "pretrain_size_clean": int(len(X_pre)),
    "sbx_size": int(len(X_sbx)),
    "pretrain_cv": pretrain_cv,
    "loocv": loocv,
    "loeo": loeo,
    "direct_train_loeo": direct_train_loeo,
    "concentration_baseline": concentration_baseline,
    "krr_loeo": krr_loeo,
    "rf_loeo": rf_loeo,
    "gnn_loeo": gnn_loeo,
    "size_ablation": size_ablation,
    "mmd": mmd,
    "shap": shap_result,
    "vif": vif_data,
    "feature_clusters": feature_clusters,
    "selected_features": selected_features,
    "dedup_transfer": dedup_transfer,
    "single_feature": single_feature,
    "permutation_test": permutation_test,
    "bootstrap_significance": bootstrap_significance,
    "elem_bootstrap_ci": elem_bootstrap_ci,
    "seed": SEED,
}

# Remove large shap values for JSON size
results["shap"].pop("shap_values", None)

with open(os.path.join(OUT, "results_fixed_no_leakage.json"), "w", encoding="utf-8") as f:
    json.dump(results, f, indent=2, ensure_ascii=False)

print(f"Results saved to results_fixed_no_leakage.json")
print("\n" + "=" * 60)
print("SUMMARY")
print("=" * 60)
print(f"Pretrain (clean): {len(X_pre)} (removed {len(df_pre_raw)-len(df_pre_clean)} Sb-X)")
print(f"LOEO R2: {loeo['r2']:.3f} (was 0.888 with leakage)")
print(f"LOEO MAE: {loeo['mae']:.3f} (was 0.139 with leakage)")
print(f"Direct training R2: {direct_train_loeo['r2']:.3f}")
print(f"Transfer gain: {loeo['r2'] - direct_train_loeo['r2']:.3f}")
print(f"GNN LOEO R2: {gnn_loeo['r2']:.3f}")
print(f"KRR LOEO R2: {krr_loeo['r2']:.3f}")
print(f"RF LOEO R2: {rf_loeo['r2']:.3f}")
print(f"Bootstrap p (R2): {bootstrap_significance['r2_p']:.4f}")
print(f"Permutation p: {permutation_test['p_value']:.4f}")
