# -*- coding: utf-8 -*-
"""修复版 active learning + Pareto（预训练排除Sb，seed=42）"""
import os, json, warnings, gc, sys
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import r2_score, mean_absolute_error
from sklearn.preprocessing import StandardScaler
from scipy.spatial.distance import cdist
from matplotlib.lines import Line2D
import importlib.util
warnings.filterwarnings("ignore")
plt.rcParams.update({"font.family":"serif","font.serif":["Times New Roman"],
    "mathtext.fontset":"stix","font.size":12,"axes.linewidth":1.3,"pdf.fonttype":42,"ps.fonttype":42})
OUT=os.path.dirname(os.path.abspath(__file__)); FIG=os.path.join(OUT,"fixed_figures")
spec=importlib.util.spec_from_file_location("pipe",os.path.join(OUT,"Code_S1_pipeline.py"))
P=importlib.util.module_from_spec(spec); spec.loader.exec_module(P)
FEATS=["epsilon","dchi","dm","dTm","c","dI","dK","VEC","epsilon2","dchi2","dm2",
       "epsilon_c","dchi_c","dm_c","dH_mix","dS_mix"]
# 关键修复：预训练排除所有Sb-X
pre_raw=pd.read_csv(os.path.join(DATA, "mp_pretrain_binary.csv"))
sb_raw=pd.read_csv(os.path.join(DATA, "mp_sbx_binary.csv"))
sb_ids=set(sb_raw.material_id)
pre_raw=pre_raw[~pre_raw.material_id.isin(sb_ids)]
dpre=P.build_pretrain_dataset(pre_raw); dsbx=P.build_sbx_dataset(sb_raw)
Xp,yp=dpre[FEATS].values,dpre["E_form"].values
X,y=dsbx[FEATS].values,dsbx["E_sub"].values
el=dsbx["elem_b"].values
pre=P.train_xgb(Xp,yp,n_estimators=300,max_depth=6,lr=0.1,seed=42)
Xs=StandardScaler().fit_transform(X)
cent={e:Xs[el==e].mean(0) for e in set(el)}
alle=sorted(set(el)); N0=10; REP=10

def curve(strat,seed0):
    rng=np.random.RandomState(seed0); e=list(alle); rng.shuffle(e)
    lab=set(e[:N0]); un=e[N0:]; out=[]
    for _ in range(len(alle)-N0+1):
        te=[x for x in alle if x not in lab]
        if len(te)<3: break
        mt=np.isin(el,list(lab)); me=np.isin(el,te)
        m=P.train_xgb(X[mt],y[mt],n_estimators=200,max_depth=4,lr=0.1,xgb_init=pre,seed=42)
        p=m.predict(X[me]); out.append((len(lab),r2_score(y[me],p),mean_absolute_error(y[me],p)))
        del m; gc.collect()
        if not un: break
        if strat=="unc":
            lc=np.array([cent[x] for x in lab])
            u={x:float(cdist(cent[x].reshape(1,-1),lc).min()) for x in un}
            nx=max(u,key=u.get)
        else: nx=un[rng.randint(len(un))]
        lab.add(nx); un.remove(nx)
    return out

mode=sys.argv[1] if len(sys.argv)>1 else "all"
if mode in ("unc","rand"):
    cc=[curve(mode,s if mode=="unc" else s+5000) for s in range(REP)]
    np.save(os.path.join(OUT,f"_fixed_al_{mode}.npy"),np.array(cc,dtype=object),allow_pickle=True)
    print(mode,"done"); raise SystemExit

cu=json.load(open(os.path.join(DATA, "_fixed_al_unc.json"), encoding="utf-8"))
cr=json.load(open(os.path.join(DATA, "_fixed_al_rand.json"), encoding="utf-8"))
def agg(cs):
    ns=sorted(set(t[0] for c in cs for t in c)); o=[]
    for n in ns:
        r2=[t[1] for c in cs for t in c if t[0]==n]; ma=[t[2] for c in cs for t in c if t[0]==n]
        o.append((n,np.mean(r2),np.std(r2),np.mean(ma),np.std(ma)))
    return [np.array(a) for a in zip(*o)]
ns,rm,rs,mm,msv=agg(cu); nr,rrm,rrs,mrm,mrs=agg(cr)
def at(nn,vv,n): return round(float(vv[list(nn).index(n)]),3) if n in nn.tolist() else None
summary={}
for nlab in [20,25,30,40,50,58]:
    summary[nlab]={"unc_r2":at(ns,rm,nlab),"rand_r2":at(nr,rrm,nlab),
                   "unc_mae":at(ns,mm,nlab),"rand_mae":at(nr,mrm,nlab)}
print(json.dumps(summary,indent=1))
fig,ax=plt.subplots(1,2,figsize=(13,5.2))
ax[0].plot(ns,rm,"-o",color="#E74C3C",ms=5,lw=2.2,label="Uncertainty-driven")
ax[0].fill_between(ns,rm-rs,rm+rs,color="#E74C3C",alpha=0.15)
ax[0].plot(nr,rrm,"-s",color="#3498DB",ms=5,lw=2.2,label="Random")
ax[0].fill_between(nr,rrm-rrs,rrm+rrs,color="#3498DB",alpha=0.15)
ax[0].set_xlabel("Number of labeled dopant elements",fontsize=14)
ax[0].set_ylabel(r"$R^2$ on unlabeled elements",fontsize=14)
ax[0].set_title("(a) Active learning curve",fontsize=15,fontweight="bold")
ax[0].legend(fontsize=11,loc="lower right");ax[0].grid(alpha=0.25,ls="--");ax[0].set_ylim(0,1)
ax[1].plot(ns,mm,"-o",color="#E74C3C",ms=5,lw=2.2,label="Uncertainty-driven")
ax[1].fill_between(ns,mm-msv,mm+msv,color="#E74C3C",alpha=0.15)
ax[1].plot(nr,mrm,"-s",color="#3498DB",ms=5,lw=2.2,label="Random")
ax[1].fill_between(nr,mrm-mrs,mrm+mrs,color="#3498DB",alpha=0.15)
ax[1].set_xlabel("Number of labeled dopant elements",fontsize=14)
ax[1].set_ylabel("MAE on unlabeled elements (eV/atom)",fontsize=14)
ax[1].set_title("(b) Error reduction",fontsize=15,fontweight="bold")
ax[1].legend(fontsize=11);ax[1].grid(alpha=0.25,ls="--")
plt.tight_layout()
plt.savefig(os.path.join(FIG,"fixed_figS9_active.png"),dpi=600,bbox_inches="tight")
plt.close()
json.dump(summary,open(os.path.join(OUT,"fixed_active_summary.json"),"w"),indent=1)
print("S9 active learning done")
