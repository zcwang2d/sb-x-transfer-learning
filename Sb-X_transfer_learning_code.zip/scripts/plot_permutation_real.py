# -*- coding: utf-8 -*-
import numpy as np, json, os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["mathtext.fontset"] = "stix"
plt.rcParams["font.size"] = 16

_HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(_HERE, "..", "results")
OUT_DIR = OUT
DATA = os.path.join(_HERE, "..", "data")
os.makedirs(OUT, exist_ok=True)
perm_r2 = np.load(os.path.join(DATA, "permutation_r2_real.npy"))
with open(os.path.join(DATA, "permutation_results_real.json"), "r") as f:
    R = json.load(f)
real_r2 = R["real_r2_loeo"]
p_val = R["p_value"]

fig, ax = plt.subplots(figsize=(7, 6))
ax.hist(perm_r2, bins=30, color="#A6A6A6", alpha=0.8, edgecolor="black", linewidth=0.5,
        label=r"Permuted $R^2$ (200 runs)")
ax.axvline(x=real_r2, color="red", linewidth=2.5, linestyle="--",
           label=f"Real model $R^2$={real_r2:.4f}")
ax.set_xlabel(r"$R^2$ (5-fold CV)", fontsize=24)
ax.set_ylabel("Frequency", fontsize=24)
p_label = max(p_val, 0.005)
ax.set_title(f"Permutation Test (p < {p_label:.3f})", fontsize=21, fontweight="bold")
ax.legend(fontsize=16)
ax.tick_params(axis="both", labelsize=16)
ax.grid(axis="y", alpha=0.2, linestyle=":")
# ax.text(0.02, 0.95, f"Total runs: {len(perm_r2)}", transform=ax.transAxes,
#         fontsize=13, va="top", ha="left",
#         bbox=dict(boxstyle="round,pad=0.3", facecolor="white", alpha=0.8))
plt.tight_layout()
plt.savefig(os.path.join(OUT, "fig2e_permutation_real.png"), dpi=300, bbox_inches="tight")
plt.close()
print("Done: fig2e_permutation_real.png (300 DPI)")
print(f"Total frequency = {len(perm_r2)}")
print(f"Mean = {np.mean(perm_r2):.4f}, Std = {np.std(perm_r2):.4f}")
print(f"Range = [{np.min(perm_r2):.4f}, {np.max(perm_r2):.4f}]")
print(f"Real R2 = {real_r2:.4f}, p = {p_val:.4f}")
