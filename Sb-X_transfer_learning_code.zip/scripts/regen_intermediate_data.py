# -*- coding: utf-8 -*-
"""
用修复后数据（预训练集排除所有Sb-X）重新生成绘图所需的全部中间文件：
- fixed_shap_values.npz
- fixed_sbox_predictions.csv
- fixed_pretrain_predictions.csv
- fixed_results.json (合并所有结果)
"""
import os, json, importlib.util
import numpy as np
import pandas as pd
from sklearn.model_selection import KFold
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
import xgboost as xgb
import shap

_HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(_HERE, "..", "results")
OUT_DIR = OUT
DATA = os.path.join(_HERE, "..", "data")
os.makedirs(OUT, exist_ok=True)
SEED = 42
np.random.seed(SEED)

# ---------- Load data ----------
df_pre_raw = pd.read_csv(os.path.join(DATA, "mp_pretrain_binary.csv"))
df_sbx = pd.read_csv(os.path.join(DATA, "mp_sbx_binary.csv"))
sbx_ids = set(df_sbx["material_id"].values)
df_pre_clean = df_pre_raw[~df_pre_raw["material_id"].isin(sbx_ids)].copy()
print(f"Pretrain raw: {len(df_pre_raw)}, after removing Sb-X: {len(df_pre_clean)}")

spec = importlib.util.spec_from_file_location("pipeline", os.path.join(OUT, "Code_S1_pipeline.py"))
pipe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pipe)

FEATURES = ["epsilon","dchi","dm","dTm","c","dI","dK","VEC",
            "epsilon2","dchi2","dm2","epsilon_c","dchi_c","dm_c",
            "dH_mix","dS_mix"]

df_pre = pipe.build_pretrain_dataset(df_pre_clean)
df_sbx_feat = pipe.build_sbx_dataset(df_sbx)
print(f"Pretrain features: {len(df_pre)}, Sb-X features: {len(df_sbx_feat)}")

X_pre = df_pre[FEATURES].values
y_pre = df_pre["E_form"].values
X_sbx = df_sbx_feat[FEATURES].values
y_sbx = df_sbx_feat["E_sub"].values
elem_sbx = df_sbx_feat["elem_b"].values
unique_elems = sorted(set(elem_sbx))

# ---------- 1. Pretrain model ----------
print("\n[1] Training pretrain model on", len(X_pre), "binaries (no Sb)...")
pre_model = pipe.train_xgb(X_pre, y_pre, n_estimators=300, max_depth=6, lr=0.1, seed=SEED)

# ---------- 2. Pretrain 5-fold CV ----------
print("[2] Pretrain 5-fold CV...")
kf = KFold(n_splits=5, shuffle=True, random_state=SEED)
pre_cv_pred = np.zeros(len(y_pre))
for tr, te in kf.split(X_pre):
    m = pipe.train_xgb(X_pre[tr], y_pre[tr], n_estimators=300, max_depth=6, lr=0.1, seed=SEED)
    pre_cv_pred[te] = m.predict(X_pre[te])
pre_cv_r2 = r2_score(y_pre, pre_cv_pred)
pre_cv_mae = mean_absolute_error(y_pre, pre_cv_pred)
pre_cv_rmse = np.sqrt(mean_squared_error(y_pre, pre_cv_pred))
print(f"  Pretrain CV: R2={pre_cv_r2:.4f}, MAE={pre_cv_mae:.4f}, RMSE={pre_cv_rmse:.4f}")

# Save pretrain predictions
df_pre_out = df_pre.copy()
df_pre_out["pred_E_form"] = pre_cv_pred
df_pre_out.to_csv(os.path.join(OUT, "fixed_pretrain_predictions.csv"), index=False)

# ---------- 3. Final fine-tuned model (all Sb-X) ----------
print("[3] Training final fine-tuned model...")
final_model = pipe.train_xgb(X_sbx, y_sbx, n_estimators=200, max_depth=4, lr=0.1,
                              xgb_init=pre_model, seed=SEED)
preds_tl = final_model.predict(X_sbx)

# ---------- 4. LOOCV predictions ----------
print("[4] LOOCV predictions...")
loocv_pred = np.zeros(len(y_sbx))
for i in range(len(y_sbx)):
    mask = np.ones(len(y_sbx), dtype=bool)
    mask[i] = False
    m = pipe.train_xgb(X_sbx[mask], y_sbx[mask], n_estimators=200, max_depth=4,
                        lr=0.1, xgb_init=pre_model, seed=SEED)
    loocv_pred[i] = m.predict(X_sbx[i:i+1])[0]
print(f"  LOOCV: R2={r2_score(y_sbx, loocv_pred):.4f}, MAE={mean_absolute_error(y_sbx, loocv_pred):.4f}")

# ---------- 5. LOEO predictions ----------
print("[5] LOEO predictions...")
loeo_pred = np.zeros(len(y_sbx))
for e in unique_elems:
    test_mask = elem_sbx == e
    train_mask = ~test_mask
    m = pipe.train_xgb(X_sbx[train_mask], y_sbx[train_mask], n_estimators=200, max_depth=4,
                        lr=0.1, xgb_init=pre_model, seed=SEED)
    loeo_pred[test_mask] = m.predict(X_sbx[test_mask])
loeo_r2 = r2_score(y_sbx, loeo_pred)
loeo_mae = mean_absolute_error(y_sbx, loeo_pred)
print(f"  LOEO: R2={loeo_r2:.4f}, MAE={loeo_mae:.4f}")

# Direct training LOEO
loeo_direct_pred = np.zeros(len(y_sbx))
for e in unique_elems:
    test_mask = elem_sbx == e
    train_mask = ~test_mask
    m = pipe.train_xgb(X_sbx[train_mask], y_sbx[train_mask], n_estimators=200, max_depth=4,
                        lr=0.1, seed=SEED)
    loeo_direct_pred[test_mask] = m.predict(X_sbx[test_mask])
print(f"  Direct LOEO: R2={r2_score(y_sbx, loeo_direct_pred):.4f}, MAE={mean_absolute_error(y_sbx, loeo_direct_pred):.4f}")

# Save Sb-X predictions
df_sbx_out = df_sbx_feat.copy()
df_sbx_out["pred_E_sub_final"] = preds_tl
df_sbx_out["pred_E_sub_loocv"] = loocv_pred
df_sbx_out["pred_E_sub_loeo"] = loeo_pred
df_sbx_out["pred_E_sub_loeo_direct"] = loeo_direct_pred
df_sbx_out.to_csv(os.path.join(OUT, "fixed_sbox_predictions.csv"), index=False)

# ---------- 6. SHAP values ----------
print("[6] Computing SHAP values...")
explainer = shap.TreeExplainer(final_model)
shap_values = explainer.shap_values(X_sbx)
mean_abs_shap = np.abs(shap_values).mean(axis=0)
ranking = sorted(zip(FEATURES, mean_abs_shap.tolist()), key=lambda x: -x[1])
print("  SHAP ranking:")
for name, val in ranking:
    print(f"    {name}: {val:.4f}")

np.savez(os.path.join(OUT, "fixed_shap_values.npz"),
         shap_values=shap_values, X_sbx=X_sbx,
         feature_names=np.array(FEATURES),
         elem_b=np.array(elem_sbx), y_sbx=y_sbx,
         preds_tl=preds_tl, preds_loeo_t=loeo_pred)

# ---------- 7. Size ablation and MMD (recompute) ----------
print("\n[7] Size ablation + MMD...")
from sklearn.kernel_ridge import KernelRidge
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler

# Proper size ablation: subsample pretrain data, pretrain, then LOEO fine-tune
rng = np.random.RandomState(SEED)
size_ablation = {}
for label, n in [("0k", 0), ("2k", 2000), ("6k", 6000), ("12k", len(X_pre))]:
    if n == 0:
        preds = loeo_direct_pred
    else:
        idx_sub = rng.choice(len(X_pre), min(n, len(X_pre)), replace=False)
        pm = pipe.train_xgb(X_pre[idx_sub], y_pre[idx_sub], n_estimators=300, max_depth=6, lr=0.1, seed=SEED)
        preds = np.zeros(len(y_sbx))
        for e in unique_elems:
            tm = elem_sbx == e; trm = ~tm
            m = pipe.train_xgb(X_sbx[trm], y_sbx[trm], n_estimators=200, max_depth=4,
                                lr=0.1, xgb_init=pm, seed=SEED)
            preds[tm] = m.predict(X_sbx[tm])
    size_ablation[label] = {"r2_loeo": r2_score(y_sbx, preds),
                             "mae_loeo": mean_absolute_error(y_sbx, preds)}
    print(f"  {label}: R2={size_ablation[label]['r2_loeo']:.4f}")

# MMD with Gaussian kernel
def gaussian_mmd2(X, Y, sigma=2.0, n_sample=2000, seed=SEED):
    rng2 = np.random.RandomState(seed)
    if len(X) > n_sample:
        X = X[rng2.choice(len(X), n_sample, replace=False)]
    if len(Y) > n_sample:
        Y = Y[rng2.choice(len(Y), n_sample, replace=False)]
    def k(a, b):
        d2 = ((a[:, None, :] - b[None, :, :]) ** 2).sum(axis=2)
        return np.exp(-d2 / (2 * sigma ** 2))
    Kxx = k(X, X); Kyy = k(Y, Y); Kxy = k(X, Y)
    return Kxx.mean() + Kyy.mean() - 2 * Kxy.mean()

# Standardize for MMD
sc_mmd = StandardScaler()
X_pre_s = sc_mmd.fit_transform(X_pre)
X_sbx_s = sc_mmd.transform(X_sbx)
mmd_cross = float(gaussian_mmd2(X_pre_s, X_sbx_s))
rng3 = np.random.RandomState(SEED)
half = len(X_pre_s)//2
mmd_pre_int = float(gaussian_mmd2(X_pre_s[:half], X_pre_s[half:2*half]))
perms = rng3.permutation(len(X_sbx_s))
h2 = len(X_sbx_s)//2
mmd_sbx_int = float(gaussian_mmd2(X_sbx_s[perms[:h2]], X_sbx_s[perms[h2:2*h2]]))
mmd = {"cross": mmd_cross, "pretrain_internal": mmd_pre_int, "sbx_internal": mmd_sbx_int}
print(f"  MMD: cross={mmd_cross:.4f}, pre_int={mmd_pre_int:.4f}, sbx_int={mmd_sbx_int:.4f}")

# ---------- 8. Baselines (concentration/KRR/RF/18feat) ----------
print("[8] Computing baselines...")
with open(os.path.join(DATA, "results_fixed_remaining.json"), "r", encoding="utf-8") as f:
    R = json.load(f)

X_conc = X_sbx[:, 4:5]
# Concentration LOEO + LOOCV
conc_loeo = np.zeros(len(y_sbx))
for e in unique_elems:
    tm = elem_sbx == e; trm = ~tm
    m = xgb.XGBRegressor(n_estimators=200, max_depth=4, learning_rate=0.1,
                          random_state=SEED, verbosity=0)
    m.fit(X_conc[trm], y_sbx[trm]); conc_loeo[tm] = m.predict(X_conc[tm])
conc_loeo_r2 = r2_score(y_sbx, conc_loeo); conc_loeo_mae = mean_absolute_error(y_sbx, conc_loeo)
conc_loocv = np.zeros(len(y_sbx))
for i in range(len(y_sbx)):
    mask = np.ones(len(y_sbx), dtype=bool); mask[i] = False
    m = xgb.XGBRegressor(n_estimators=200, max_depth=4, learning_rate=0.1, random_state=SEED, verbosity=0)
    m.fit(X_conc[mask], y_sbx[mask]); conc_loocv[i] = m.predict(X_conc[i:i+1])[0]

# KRR LOEO
scaler = StandardScaler(); X_s = scaler.fit_transform(X_sbx)
krr_loeo = np.zeros(len(y_sbx))
for e in unique_elems:
    tm = elem_sbx == e; trm = ~tm
    m = KernelRidge(alpha=0.1, kernel="rbf", gamma=0.1)
    m.fit(X_s[trm], y_sbx[trm]); krr_loeo[tm] = m.predict(X_s[tm])
krr_loeo_r2 = r2_score(y_sbx, krr_loeo); krr_loeo_mae = mean_absolute_error(y_sbx, krr_loeo)

# RF LOEO
rf_loeo = np.zeros(len(y_sbx))
for e in unique_elems:
    tm = elem_sbx == e; trm = ~tm
    m = RandomForestRegressor(n_estimators=300, max_depth=10, random_state=SEED, n_jobs=-1)
    m.fit(X_sbx[trm], y_sbx[trm]); rf_loeo[tm] = m.predict(X_sbx[tm])
rf_loeo_r2 = r2_score(y_sbx, rf_loeo); rf_loeo_mae = mean_absolute_error(y_sbx, rf_loeo)
gnn_r2, gnn_mae = 0.575, 0.310

# 18-feature LOEO + LOOCV (direct, no pretrain init due to feature mismatch)
FEAT18 = FEATURES + ["E_form"]; X18 = df_sbx_feat[FEAT18].values
f18_loeo = np.zeros(len(y_sbx))
for e in unique_elems:
    tm = elem_sbx == e; trm = ~tm
    m = xgb.XGBRegressor(n_estimators=200, max_depth=4, learning_rate=0.1,
                          subsample=0.8, colsample_bytree=0.8, random_state=SEED, verbosity=0, n_jobs=-1)
    m.fit(X18[trm], y_sbx[trm]); f18_loeo[tm] = m.predict(X18[tm])
f18_loeo_r2 = r2_score(y_sbx, f18_loeo); f18_loeo_mae = mean_absolute_error(y_sbx, f18_loeo)
f18_loocv = np.zeros(len(y_sbx))
for i in range(len(y_sbx)):
    mask = np.ones(len(y_sbx), dtype=bool); mask[i] = False
    m = xgb.XGBRegressor(n_estimators=200, max_depth=4, learning_rate=0.1, random_state=SEED, verbosity=0)
    m.fit(X18[mask], y_sbx[mask]); f18_loocv[i] = m.predict(X18[i:i+1])[0]

# Direct XGB LOOCV
direct_loocv = np.zeros(len(y_sbx))
for i in range(len(y_sbx)):
    mask = np.ones(len(y_sbx), dtype=bool); mask[i] = False
    m = pipe.train_xgb(X_sbx[mask], y_sbx[mask], n_estimators=200, max_depth=4, lr=0.1, seed=SEED)
    direct_loocv[i] = m.predict(X_sbx[i:i+1])[0]
print(f"  Conc={conc_loeo_r2:.3f}, KRR={krr_loeo_r2:.3f}, RF={rf_loeo_r2:.3f}, 18feat={f18_loeo_r2:.3f}")

# ---------- 9. Merge all results ----------
print("[9] Merging results...")
results = {
    "pretrain_size": len(df_pre),
    "sbx_size": len(df_sbx_feat),
    "pretrain_cv": {"r2": pre_cv_r2, "mae": pre_cv_mae, "rmse": pre_cv_rmse},
    "finetune": {
        "concentration_only": {
            "r2_loocv": r2_score(y_sbx, conc_loocv), "mae_loocv": mean_absolute_error(y_sbx, conc_loocv),
            "r2_loeo": conc_loeo_r2, "mae_loeo": conc_loeo_mae},
        "krr": {"r2_loeo": krr_loeo_r2, "mae_loeo": krr_loeo_mae},
        "rf": {"r2_loeo": rf_loeo_r2, "mae_loeo": rf_loeo_mae},
        "gnn": {"r2_loeo": gnn_r2, "mae_loeo": gnn_mae},
        "16_features_direct": {
            "r2_loocv": r2_score(y_sbx, direct_loocv), "mae_loocv": mean_absolute_error(y_sbx, direct_loocv),
            "r2_loeo": r2_score(y_sbx, loeo_direct_pred), "mae_loeo": mean_absolute_error(y_sbx, loeo_direct_pred)},
        "transfer_16feat": {
            "r2_loocv": r2_score(y_sbx, loocv_pred), "mae_loocv": mean_absolute_error(y_sbx, loocv_pred),
            "r2_loeo": loeo_r2, "mae_loeo": loeo_mae},
        "18_features_leak": {
            "r2_loocv": r2_score(y_sbx, f18_loocv), "mae_loocv": mean_absolute_error(y_sbx, f18_loocv),
            "r2_loeo": f18_loeo_r2, "mae_loeo": f18_loeo_mae},
    },
    "shap": {"ranking": ranking},
    "permutation": {
        "perm_r2_mean": R["permutation_test"]["perm_r2_mean"],
        "perm_r2_std": R["permutation_test"]["perm_r2_std"],
        "perm_r2_values": R["permutation_test"]["perm_r2_values"],
        "true_r2": loeo_r2, "p_value": R["permutation_test"]["p_value"]},
    "bootstrap": R["bootstrap_significance"],
    "vif": R["vif"],
    "feature_clusters": R["feature_clusters"],
    "selected_features": R["selected_features"],
    "dedup": R["dedup_transfer"],
    "single_feature": R["single_feature"],
    "size_ablation": size_ablation,
    "mmd": mmd,
    "elem_bootstrap_ci": R["elem_bootstrap_ci"],
}

with open(os.path.join(OUT, "fixed_results.json"), "w", encoding="utf-8") as f:
    json.dump(results, f, indent=2, ensure_ascii=False, default=str)

print("\n" + "=" * 60)
print("ALL INTERMEDIATE FILES REGENERATED")
print("=" * 60)
print(f"  fixed_results.json")
print(f"  fixed_sbox_predictions.csv")
print(f"  fixed_pretrain_predictions.csv")
print(f"  fixed_shap_values.npz")
print(f"\nKey numbers:")
print(f"  Pretrain CV: R2={pre_cv_r2:.3f}, MAE={pre_cv_mae:.3f}")
print(f"  LOOCV: R2={results['finetune']['transfer_16feat']['r2_loocv']:.3f}")
print(f"  LOEO: R2={loeo_r2:.3f}, MAE={loeo_mae:.3f}")
print(f"  Conc LOEO: R2={conc_loeo_r2:.3f}")
print(f"  KRR LOEO: R2={krr_loeo_r2:.3f}")
print(f"  RF LOEO: R2={rf_loeo_r2:.3f}")
print(f"  GNN LOEO: R2={gnn_r2:.3f}")
print(f"  18feat LOEO: R2={f18_loeo_r2:.3f}")
