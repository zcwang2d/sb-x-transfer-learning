# -*- coding: utf-8 -*-
"""B0 vs AUG 多种子稳健性: 5种子下预训练+LOEO续训都换种子, 看提升是否大于波动"""
import os, importlib.util, warnings
import numpy as np, pandas as pd
warnings.filterwarnings("ignore")
from pymatgen.core import Element
from sklearn.metrics import r2_score, mean_absolute_error
HERE=os.path.dirname(os.path.abspath(__file__))
DATA=os.path.join(HERE,"..","data")
spec=importlib.util.spec_from_file_location("pipe",os.path.join(HERE,"Code_S1_pipeline.py"))
pipe=importlib.util.module_from_spec(spec); spec.loader.exec_module(pipe)
FEAT=pipe.FEATURE_NAMES_16; AUG=["dMend","dRow","dGroup","dEAff","dMVol","dKth"]; ALL=FEAT+AUG
PBLOCK=["P","As","Se","Ge","Si","B","C","N","S","Bi","Sn","Al","Ga","In","Tl","Pb"]; SEEDS=[42,7,123,2024,2025]
pre_raw=pd.read_csv(os.path.join(DATA,"mp_pretrain_binary.csv")); sbx_raw=pd.read_csv(os.path.join(DATA,"mp_sbx_binary.csv"))
ids=set(sbx_raw.material_id)
pre=pipe.build_pretrain_dataset(pre_raw[~pre_raw.material_id.isin(ids)]); sbx=pipe.build_sbx_dataset(sbx_raw)
_c={}
def aug(ea,eb):
    k=(ea,eb)
    if k in _c:return _c[k]
    A,B=Element(ea),Element(eb)
    _c[k]=[abs(B.mendeleev_no-A.mendeleev_no),abs(B.row-A.row),abs((B.group or 0)-(A.group or 0)),
           abs((B.electron_affinity or 0)-(A.electron_affinity or 0)),
           abs(B.molar_volume-A.molar_volume)/(A.molar_volume+1e-9),
           abs((B.thermal_conductivity or 0)-(A.thermal_conductivity or 0))/(A.thermal_conductivity+1e-9)]
    return _c[k]
for df in (pre,sbx):
    M=np.array([aug(a,b) for a,b in zip(df.elem_a,df.elem_b)])
    for j,a in enumerate(AUG): df[a]=M[:,j]
yt=sbx.E_sub.values; et=sbx.elem_b.values; pmask=np.isin(et,PBLOCK)
def loeo(pm,X,sd):
    pr=np.zeros(len(yt))
    for e in sorted(set(et)):
        te=et==e; tr=~te
        m=pipe.train_xgb(X[tr],yt[tr],n_estimators=200,max_depth=4,lr=0.1,xgb_init=pm,seed=sd)
        pr[te]=m.predict(X[te])
    return pr
for tag,feat in [("B0",FEAT),("AUG",ALL)]:
    Xp=pre[feat].values; Xt=sbx[feat].values; R=[];M=[];P=[]
    for sd in SEEDS:
        pm=pipe.train_xgb(Xp,pre.E_form.values,n_estimators=300,max_depth=6,lr=0.1,seed=sd)
        pr=loeo(pm,Xt,sd)
        R.append(r2_score(yt,pr));M.append(mean_absolute_error(yt,pr));P.append(mean_absolute_error(yt[pmask],pr[pmask]))
    print("%-4s 全局R2=%.4f±%.4f  全局MAE=%.4f±%.4f  p区MAE=%.4f±%.4f"%(
        tag,np.mean(R),np.std(R,ddof=1),np.mean(M),np.std(M,ddof=1),np.mean(P),np.std(P,ddof=1)))
    print("     R2各种子",[round(x,4) for x in R]); print("     MAE各种子",[round(x,4) for x in M])
