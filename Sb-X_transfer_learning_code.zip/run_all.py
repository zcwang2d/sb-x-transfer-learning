# -*- coding: utf-8 -*-
"""One-click reproduction. Run from the code/ root folder: python run_all.py"""
import os, subprocess, sys

ROOT = os.path.dirname(os.path.abspath(__file__))
SCRIPTS = os.path.join(ROOT, "scripts")
os.makedirs(os.path.join(ROOT, "results"), exist_ok=True)

# Ordered pipeline. Each script reads inputs from data/ and writes to results/.
STEPS = [
 "Code_S1_pipeline.py",        # build features, train transfer model, SHAP
 "unify_baselines.py",         # KRR/RF/direct/transfer comparison, MMD, ablation
 "opt_compare.py",             # weighted-score comparison
 "opt_robust.py",              # weight/optimum robustness sweep
 "rank_pblock.py",             # p-block candidate ranking
 "predict_si.py",             # Si-Sb extrapolation
 "exp_validation2.py",         # five equiatomic antimonides vs experiment
 "run_permutation_real.py",   # permutation test
 "rerun_fixed_active.py",      # active-learning simulation
]

for s in STEPS:
    print("\n" + "=" * 60 + f"\nRUN {s}\n" + "=" * 60)
    r = subprocess.run([sys.executable, os.path.join(SCRIPTS, s)], cwd=SCRIPTS)
    if r.returncode != 0:
        print(f"!! {s} failed (exit {r.returncode})")
        sys.exit(1)

print("\nAll steps done. Outputs are in:", os.path.join(ROOT, "results"))
